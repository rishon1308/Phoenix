package com.gourmet.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestaurantFoodOrderingApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestaurantFoodOrderingApplication.class, args);
	}

}
