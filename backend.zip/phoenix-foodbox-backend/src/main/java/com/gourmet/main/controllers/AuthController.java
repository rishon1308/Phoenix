package com.gourmet.main.controllers;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import com.gourmet.main.entities.User;
import com.gourmet.main.responses.ApiResponse;
import com.gourmet.main.services.UserService;
import com.gourmet.main.util.JwtUtil;

@RestController
@RequestMapping("/api/auth") // Matches Frontend URL
public class AuthController {

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private UserService userService;

    @Autowired
    private JwtUtil jwtUtil;
    
    @Autowired
    private PasswordEncoder passwordEncoder;

    // 1. LOGIN ENDPOINT
    @PostMapping("/login")
    public ResponseEntity<ApiResponse<Map<String, String>>> login(@RequestBody User loginRequest) {
        try {
            // Attempt Authentication
            Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(loginRequest.getUsername(), loginRequest.getPassword())
            );

            // Generate Token
            UserDetails userDetails = (UserDetails) authentication.getPrincipal();
            String token = jwtUtil.generateToken(userDetails.getUsername());
            
            // Get Role
            String role = userDetails.getAuthorities().stream()
                            .findFirst()
                            .map(item -> item.getAuthority())
                            .orElse("ROLE_CUSTOMER");

            // Prepare Response Data (Using HashMap for Java 8+ compatibility)
            Map<String, String> data = new HashMap<>();
            data.put("token", token);
            data.put("username", userDetails.getUsername());
            data.put("role", role);
            
            return ResponseEntity.ok(new ApiResponse<>("Login successful", data));

        } catch (BadCredentialsException e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(new ApiResponse<>("Invalid username or password", null));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ApiResponse<>("Login failed: " + e.getMessage(), null));
        }
    }

    // 2. REGISTER ENDPOINT
    @PostMapping("/register")
    public ResponseEntity<ApiResponse<String>> register(@RequestBody User user) {
        try {
            if(userService.findByUsername(user.getUsername()).isPresent()) {
                 return ResponseEntity.status(HttpStatus.CONFLICT)
                         .body(new ApiResponse<>("Username already exists", null));
            }
            
            // Set Default Role and Encode Password
            user.setRoles("ROLE_CUSTOMER");
            user.setPassword(passwordEncoder.encode(user.getPassword()));
            
            userService.saveUser(user);
            
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(new ApiResponse<>("User registered successfully", null));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ApiResponse<>("Registration failed", null));
        }
    }
}