package com.gourmet.main.servicesImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.gourmet.main.entities.User;
import com.gourmet.main.repository.UserRepository;
import com.gourmet.main.services.UserService;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    // 1. Find by Username (Critical for Auth)
    @Override
    public Optional<User> findByUsername(String username) {
        return userRepository.findByUsername(username);
    }

    // 2. Save User (Register)
    @Override
    public User saveUser(User user) {
        return userRepository.save(user);
    }

    // 3. Get All Users (Admin)
    @Override
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    // 4. Update User
    @Override
    public User updateUser(Long id, User userDetails) {
        User existingUser = userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found with id: " + id));

        // Update Username
        if (userDetails.getUsername() != null && !userDetails.getUsername().isEmpty()) {
            // Check if new username exists and belongs to someone else
            Optional<User> check = userRepository.findByUsername(userDetails.getUsername());
            if (check.isPresent() && !check.get().getUser_id().equals(id)) {
                throw new RuntimeException("Username already taken!");
            }
            existingUser.setUsername(userDetails.getUsername());
        }
        
        // Update Password (Encode it)
        if (userDetails.getPassword() != null && !userDetails.getPassword().isEmpty()) {
             existingUser.setPassword(passwordEncoder.encode(userDetails.getPassword()));
        }
        
        // Update Roles
        if (userDetails.getRoles() != null) {
            existingUser.setRoles(userDetails.getRoles());
        }

        return userRepository.save(existingUser);
    }
}