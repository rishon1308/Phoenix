package com.gourmet.main.services;

import java.util.List;
import com.gourmet.main.dtos.OutletDTO;
import com.gourmet.main.entities.Outlet;

public interface OutletService {
    Outlet addOutlet(OutletDTO outletDTO);
    List<Outlet> getAllOutlets();
    List<Outlet> getOutletsByArea(String area); // NEW METHOD
    Outlet getOutletById(Long id);
    void deleteOutlet(Long id);
}