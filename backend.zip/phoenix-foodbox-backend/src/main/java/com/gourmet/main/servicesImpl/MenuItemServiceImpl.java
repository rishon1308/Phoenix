package com.gourmet.main.servicesImpl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gourmet.main.dtos.MenuItemDTO;
import com.gourmet.main.entities.MenuItem;
import com.gourmet.main.entities.Outlet;
import com.gourmet.main.repository.MenuItemRepository;
import com.gourmet.main.repository.OutletRepository;
import com.gourmet.main.services.MenuItemService;

@Service
public class MenuItemServiceImpl implements MenuItemService {

    @Autowired
    private MenuItemRepository menuItemRepository;
    
    @Autowired
    private OutletRepository outletRepository;

    @Override
    public MenuItem addFoodItem(MenuItemDTO menuItemDTO) {
        // 1. Find the outlet
        Outlet outlet = outletRepository.findById(menuItemDTO.getOutletId())
                .orElseThrow(() -> new RuntimeException("Outlet not found with id: " + menuItemDTO.getOutletId()));

        // 2. Create Entity and Map fields (Including Image)
        MenuItem menuItem = new MenuItem();
        menuItem.setFoodName(menuItemDTO.getFoodName());
        menuItem.setFoodPrice(menuItemDTO.getFoodPrice());
        menuItem.setImageUrl(menuItemDTO.getImageUrl()); // <--- ADDED
        menuItem.setOutlet(outlet);
        
        return menuItemRepository.save(menuItem);
    }

    @Override
    public List<MenuItem> getAllItems() {
        return menuItemRepository.findAll();
    }
    
    @Override
    public List<MenuItem> getItemsByOutletId(Long outletId) {
        return menuItemRepository.findByOutletId(outletId);
    }

    @Override
    public MenuItem updateFoodItemById(Long id, MenuItemDTO menuItemDTO) {
        MenuItem existingItem = menuItemRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Item not found"));
        
        // Update basic fields
        existingItem.setFoodName(menuItemDTO.getFoodName());
        existingItem.setFoodPrice(menuItemDTO.getFoodPrice());
        existingItem.setImageUrl(menuItemDTO.getImageUrl()); // <--- ADDED
        
        // Update outlet if changed
        if (menuItemDTO.getOutletId() != null) {
            Outlet outlet = outletRepository.findById(menuItemDTO.getOutletId())
                    .orElseThrow(() -> new RuntimeException("Outlet not found"));
            existingItem.setOutlet(outlet);
        }
        
        return menuItemRepository.save(existingItem);
    }

    @Override
    public void deleteFoodItemById(Long id) {
        if (!menuItemRepository.existsById(id)) {
            throw new RuntimeException("Item not found");
        }
        menuItemRepository.deleteById(id);
    }
}