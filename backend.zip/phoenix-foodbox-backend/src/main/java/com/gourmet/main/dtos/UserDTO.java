package com.gourmet.main.dtos;

import jakarta.validation.constraints.Pattern;

public class UserDTO {

    private Long user_id;

    @Pattern(regexp = "^[A-Z][a-zA-Z0-9]{2,11}$", message = "Username should be 3 to 12 characters long, start with a capital letter, and can include numbers.")
    private String username;

    @Pattern(regexp = "^(?=.*[!@#$%^&*]).{4,10}$", message = "Password should be 4 to 10 characters long with at least 1 special character.")
    private String password;

    @Pattern(regexp = "ROLE_ADMIN|ROLE_CUSTOMER", message = "Role should be either ROLE_ADMIN or ROLE_CUSTOMER.")
    private String roles;

    public Long getUser_id() {
        return user_id;
    }

    public void setUser_id(Long user_id) {
        this.user_id = user_id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRoles() {
        return roles;
    }

    public void setRoles(String roles) {
        this.roles = roles;
    }
}