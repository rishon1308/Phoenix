package com.gourmet.main.controllers;

import java.security.Principal;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import com.gourmet.main.dtos.CustomerOrderDTO;
import com.gourmet.main.entities.CustomerOrder;
import com.gourmet.main.responses.ApiResponse;
import com.gourmet.main.services.CustomerOrderService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/orders") // RECOMMENDED: Group under /api/orders
public class CustomerOrderController {

    private static final Logger logger = LoggerFactory.getLogger(CustomerOrderController.class);

    @Autowired
    private CustomerOrderService customerOrderService;  

    // 1. PLACE ORDER (Customer)
    @PostMapping("/place")
    @PreAuthorize("hasRole('ROLE_CUSTOMER') or hasRole('ROLE_ADMIN')")
    public ResponseEntity<ApiResponse<String>> placeOrder(@Valid @RequestBody CustomerOrderDTO orderDetails) {
        logger.info("Placing order for customer: {}", orderDetails.getCustomerName());
        customerOrderService.createOrder(orderDetails);
        return new ResponseEntity<>(new ApiResponse<>("Order placed successfully!", null), HttpStatus.CREATED);
    }

    // 2. GET MY ORDERS (Logged-in Customer)
    @GetMapping("/my-orders")
    @PreAuthorize("hasRole('ROLE_CUSTOMER')")
    public ResponseEntity<ApiResponse<List<CustomerOrder>>> getMyOrders(Principal principal) {
        String username = principal.getName();
        logger.info("Fetching orders for user: {}", username);
        List<CustomerOrder> orders = customerOrderService.getOrdersByUsername(username);
        return ResponseEntity.ok(new ApiResponse<>("My orders fetched successfully!", orders));
    }

    // 3. GET ALL ORDERS (Admin Dashboard - Formatted for Table)
    @GetMapping("/all")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<List<Map<String, Object>>> getAllOrdersForAdmin() {
        logger.info("Fetching all orders for Admin");
        // Returning List directly to match your Frontend AdminComponent expectation
        return ResponseEntity.ok(customerOrderService.getAllOrdersForCooks());
    }

    // 4. DELETE ORDER (Cancel Order - Admin OR Owner)
    @DeleteMapping("/delete/{id}")
    @PreAuthorize("hasRole('ROLE_ADMIN') or hasRole('ROLE_CUSTOMER')")
    public ResponseEntity<ApiResponse<String>> deleteOrder(@PathVariable Long id) {
        logger.info("Deleting order ID: {}", id);
        try {
            customerOrderService.deleteOrder(id);
            return ResponseEntity.ok(new ApiResponse<>("Order deleted successfully!", null));
        } catch (RuntimeException e) {
            logger.error("Error deleting order: ", e);
            // Return 400 or 500 depending on the error, preventing crash
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ApiResponse<>("Failed to delete order: " + e.getMessage(), null));
        }
    }

    // 5. GET ORDER BY ID
    @GetMapping("/{id}")
    @PreAuthorize("hasRole('ROLE_ADMIN') or hasRole('ROLE_CUSTOMER')")
    public ResponseEntity<ApiResponse<CustomerOrder>> getOrderById(@PathVariable Long id) {
        CustomerOrder order = customerOrderService.getOrderById(id);
        return ResponseEntity.ok(new ApiResponse<>("Order fetched successfully!", order));
    }
    
    // 6. UPDATE ORDER (For editing items in My Orders)
    @PutMapping("/update/{id}")
    @PreAuthorize("hasRole('ROLE_CUSTOMER') or hasRole('ROLE_ADMIN')")
    public ResponseEntity<ApiResponse<String>> updateOrder(
            @PathVariable Long id, 
            @Valid @RequestBody CustomerOrderDTO orderDetails) {
            
        logger.info("Updating order ID: {}", id);
        customerOrderService.updateOrderById(id, orderDetails);
        return ResponseEntity.ok(new ApiResponse<>("Order updated successfully!", null));
    }
}