package com.gourmet.main.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.gourmet.main.entities.MenuItem;

@Repository
public interface MenuItemRepository extends JpaRepository<MenuItem, Long> {
	
    // NEW: Fetch all menu items belonging to a specific outlet
    List<MenuItem> findByOutletId(Long outletId);
}