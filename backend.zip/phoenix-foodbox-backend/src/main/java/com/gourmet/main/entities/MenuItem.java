package com.gourmet.main.entities;

import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "menu_items")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class MenuItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "food_name")
    private String foodName;

    @Column(name = "food_price")
    private double foodPrice;

    // NEW: Image URL field
    @Column(name = "image_url", length = 500) // Length 500 to support long URLs
    private String imageUrl;

    // Link to Outlet
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "outlet_id")
    @JsonIgnoreProperties("menuItems") // Prevent recursion
    private Outlet outlet;

    public MenuItem() {
        super();
    }

    public MenuItem(String foodName, double foodPrice, String imageUrl, Outlet outlet) {
        this.foodName = foodName;
        this.foodPrice = foodPrice;
        this.imageUrl = imageUrl;
        this.outlet = outlet;
    }
    
    // Legacy constructor
    public MenuItem(String foodName, double foodPrice, Outlet outlet) {
        this.foodName = foodName;
        this.foodPrice = foodPrice;
        this.outlet = outlet;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFoodName() {
        return foodName;
    }

    public void setFoodName(String foodName) {
        this.foodName = foodName;
    }

    public double getFoodPrice() {
        return foodPrice;
    }

    public void setFoodPrice(double foodPrice) {
        this.foodPrice = foodPrice;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public Outlet getOutlet() {
        return outlet;
    }

    public void setOutlet(Outlet outlet) {
        this.outlet = outlet;
    }
}