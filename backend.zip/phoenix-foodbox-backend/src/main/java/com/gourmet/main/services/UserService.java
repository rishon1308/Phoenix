package com.gourmet.main.services;

import java.util.List;
import java.util.Optional;
import com.gourmet.main.entities.User;

public interface UserService {
    
    // Critical for AuthController
    Optional<User> findByUsername(String username);
    
    // Save or Register a new user
    User saveUser(User user);

    // Get all users (Admin view)
    List<User> getAllUsers();
    
    // Update user details
    User updateUser(Long id, User userDetails);
}