package com.gourmet.main.dtos;

import jakarta.validation.constraints.NotBlank;

public class OutletDTO {
    
    @NotBlank(message = "Outlet Name is required")
    private String outletName;
    
    @NotBlank(message = "Area is required")
    private String area; // NEW FIELD

    private String outletDescription;
    private String imageUrl;

    // Getters and Setters
    public String getOutletName() { return outletName; }
    public void setOutletName(String outletName) { this.outletName = outletName; }
    
    public String getArea() { return area; }
    public void setArea(String area) { this.area = area; }

    public String getOutletDescription() { return outletDescription; }
    public void setOutletDescription(String outletDescription) { this.outletDescription = outletDescription; }
    
    public String getImageUrl() { return imageUrl; }
    public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }
}