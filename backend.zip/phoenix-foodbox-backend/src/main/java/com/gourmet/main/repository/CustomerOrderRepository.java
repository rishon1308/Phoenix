package com.gourmet.main.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.gourmet.main.entities.CustomerOrder;
import com.gourmet.main.entities.User;

@Repository
public interface CustomerOrderRepository extends JpaRepository<CustomerOrder, Long> {

    // Find orders belonging to a specific user (Customer History)
    List<CustomerOrder> findByUser(User user);
    
    // Find orders belonging to a specific outlet (Admin/Cook View)
    List<CustomerOrder> findByOutletId(Long outletId);
    
    // Optional: Find by User AND sort by ID descending (newest first)
    List<CustomerOrder> findByUserOrderByIdDesc(User user);
}