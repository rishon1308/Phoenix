package com.gourmet.main.entities;

import java.util.List;
import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "outlets")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Outlet {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "outlet_name")
    private String outletName; // e.g., "KFC", "McDonalds"

    @Column(name = "area") 
    private String area; // NEW FIELD: e.g., "Indiranagar", "Whitefield"

    @Column(name = "outlet_description")
    private String outletDescription;

    @Column(name = "image_url")
    private String imageUrl;

    @OneToMany(mappedBy = "outlet", cascade = CascadeType.ALL)
    @JsonIgnore
    private List<MenuItem> menuItems;

    @OneToMany(mappedBy = "outlet", cascade = CascadeType.ALL)
    @JsonIgnore
    private List<CustomerOrder> orders;

    public Outlet() { super(); }

    // Updated Constructor
    public Outlet(String outletName, String area, String outletDescription, String imageUrl) {
        super();
        this.outletName = outletName;
        this.area = area;
        this.outletDescription = outletDescription;
        this.imageUrl = imageUrl;
    }

    // Getters & Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    
    public String getOutletName() { return outletName; }
    public void setOutletName(String outletName) { this.outletName = outletName; }
    
    public String getArea() { return area; } 
    public void setArea(String area) { this.area = area; } 
    
    public String getOutletDescription() { return outletDescription; }
    public void setOutletDescription(String outletDescription) { this.outletDescription = outletDescription; }
    
    public String getImageUrl() { return imageUrl; }
    public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }
    
    public List<MenuItem> getMenuItems() { return menuItems; }
    public void setMenuItems(List<MenuItem> menuItems) { this.menuItems = menuItems; }
    
    public List<CustomerOrder> getOrders() { return orders; }
    public void setOrders(List<CustomerOrder> orders) { this.orders = orders; }
}