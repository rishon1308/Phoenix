package com.gourmet.main;

import java.util.Arrays;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import com.gourmet.main.entities.MenuItem;
import com.gourmet.main.entities.Outlet;
import com.gourmet.main.entities.User;
import com.gourmet.main.repository.MenuItemRepository;
import com.gourmet.main.repository.OutletRepository;
import com.gourmet.main.repository.UserRepository;

@Component
public class ApplicationDataLoader implements ApplicationRunner {
	
	@Autowired private MenuItemRepository menuItemRepository;
	@Autowired private UserRepository userRepository;
	@Autowired private OutletRepository outletRepository;
	@Autowired private PasswordEncoder passwordEncoder;

	@Override
	public void run(ApplicationArguments args) throws Exception {
		
		// Load data only if outlets are empty
		if(outletRepository.count() == 0) {	
			
			// =================================================================================
			// 1. INDIRANAGAR AREA (KFC, McDonald's, Pizza Hut)
			// =================================================================================
			Outlet kfcIndira = new Outlet("KFC", "Indiranagar", "Finger Lickin' Good", "https://plus.unsplash.com/premium_photo-1683657860906-d49d1bb37aab?q=80&w=870&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D");
			Outlet mcdIndira = new Outlet("McDonald's", "Indiranagar", "I'm Lovin' It", "https://images.unsplash.com/photo-1552566626-52f8b828add9?w=800&q=80");
			Outlet pizzaHutIndira = new Outlet("Pizza Hut", "Indiranagar", "Tastiest Pizzas", "https://images.unsplash.com/photo-1513104890138-7c749659a591?w=800&q=80");
			
			outletRepository.saveAll(Arrays.asList(kfcIndira, mcdIndira, pizzaHutIndira));
			
			// --- KFC Menu (9 Items) ---
			menuItemRepository.saveAll(Arrays.asList(
				new MenuItem("Zinger Burger", 189.00, kfcIndira),
				new MenuItem("Hot & Crispy (2pc)", 229.00, kfcIndira),
				new MenuItem("Popcorn Chicken Large", 219.00, kfcIndira),
				new MenuItem("Smoky Grilled Chicken", 239.00, kfcIndira),
				new MenuItem("Chicken Strips (3pc)", 169.00, kfcIndira),
				new MenuItem("Veg Zinger Burger", 159.00, kfcIndira),
				new MenuItem("Rice Bowl with Chicken", 199.00, kfcIndira),
				new MenuItem("Choco Mud Pie", 89.00, kfcIndira),
				new MenuItem("Krushers Oreo", 129.00, kfcIndira)
			));

			// --- McDonald's Menu (9 Items) ---
			menuItemRepository.saveAll(Arrays.asList(
				new MenuItem("McAloo Tikki", 59.00, mcdIndira),
				new MenuItem("McSpicy Paneer", 179.00, mcdIndira),
				new MenuItem("McChicken", 129.00, mcdIndira),
				new MenuItem("McSpicy Chicken", 189.00, mcdIndira),
				new MenuItem("Maharaja Mac Veg", 209.00, mcdIndira),
				new MenuItem("Maharaja Mac Chicken", 239.00, mcdIndira),
				new MenuItem("Fries (L)", 109.00, mcdIndira),
				new MenuItem("McFlurry Oreo", 99.00, mcdIndira),
				new MenuItem("Coke Float", 79.00, mcdIndira)
			));

			// --- Pizza Hut Menu (9 Items) ---
			menuItemRepository.saveAll(Arrays.asList(
				new MenuItem("Margherita", 149.00, pizzaHutIndira),
				new MenuItem("Veggie Supreme", 349.00, pizzaHutIndira),
				new MenuItem("Chicken Tikka Pizza", 399.00, pizzaHutIndira),
				new MenuItem("Pepperoni Pizza", 449.00, pizzaHutIndira),
				new MenuItem("Paneer Tandoori", 379.00, pizzaHutIndira),
				new MenuItem("Garlic Bread Stix", 109.00, pizzaHutIndira),
				new MenuItem("Cheesy Garlic Bread", 149.00, pizzaHutIndira),
				new MenuItem("Choco Volcano Cake", 119.00, pizzaHutIndira),
				new MenuItem("Pepsi (500ml)", 60.00, pizzaHutIndira)
			));


			// =================================================================================
			// 2. WHITEFIELD AREA (Domino's, Subway, Starbucks)
			// =================================================================================
			Outlet dominosWhite = new Outlet("Domino's", "Whitefield", "Dil, Dosti, Domino's", "https://images.unsplash.com/photo-1590947132387-155cc02f3212?w=800&q=80");
			Outlet subwayWhite = new Outlet("Subway", "Whitefield", "Eat Fresh", "https://images.unsplash.com/photo-1509722747041-616f39b57569?w=800&q=80");
			Outlet starbucksWhite = new Outlet("Starbucks", "Whitefield", "Premium Coffee Experience", "https://images.unsplash.com/photo-1509042239860-f550ce710b93?w=800&q=80");

			outletRepository.saveAll(Arrays.asList(dominosWhite, subwayWhite, starbucksWhite));

			// --- Domino's Menu (9 Items) ---
			menuItemRepository.saveAll(Arrays.asList(
				new MenuItem("Farmhouse Pizza", 399.00, dominosWhite),
				new MenuItem("Peppy Paneer", 389.00, dominosWhite),
				new MenuItem("Chicken Dominator", 499.00, dominosWhite),
				new MenuItem("Non-Veg Supreme", 529.00, dominosWhite),
				new MenuItem("Cheese Burst Margherita", 299.00, dominosWhite),
				new MenuItem("Garlic Breadsticks", 109.00, dominosWhite),
				new MenuItem("Stuffed Garlic Bread", 159.00, dominosWhite),
				new MenuItem("Choco Lava Cake", 99.00, dominosWhite),
				new MenuItem("Taco Mexicana Veg", 129.00, dominosWhite)
			));

			// --- Subway Menu (9 Items) ---
			menuItemRepository.saveAll(Arrays.asList(
				new MenuItem("Veggie Delite Sub", 180.00, subwayWhite),
				new MenuItem("Paneer Tikka Sub", 220.00, subwayWhite),
				new MenuItem("Chicken Teriyaki", 250.00, subwayWhite),
				new MenuItem("Roasted Chicken Sub", 240.00, subwayWhite),
				new MenuItem("Tuna Sub", 260.00, subwayWhite),
				new MenuItem("Turkey Breast Sub", 280.00, subwayWhite),
				new MenuItem("Salad Bowl Veg", 220.00, subwayWhite),
				new MenuItem("Salad Bowl Chicken", 290.00, subwayWhite),
				new MenuItem("Chocolate Chip Cookie", 50.00, subwayWhite)
			));

			// --- Starbucks Menu (9 Items) ---
			menuItemRepository.saveAll(Arrays.asList(
				new MenuItem("Java Chip Frappuccino", 290.00, starbucksWhite),
				new MenuItem("Caramel Macchiato", 270.00, starbucksWhite),
				new MenuItem("Vanilla Latte", 250.00, starbucksWhite),
				new MenuItem("Cold Brew", 230.00, starbucksWhite),
				new MenuItem("Signature Hot Chocolate", 240.00, starbucksWhite),
				new MenuItem("Blueberry Muffin", 190.00, starbucksWhite),
				new MenuItem("Butter Croissant", 180.00, starbucksWhite),
				new MenuItem("Chicken & Cheese Sandwich", 280.00, starbucksWhite),
				new MenuItem("Paneer Tikka Sandwich", 260.00, starbucksWhite)
			));


			// =================================================================================
			// 3. KORAMANGALA AREA (Taco Bell, Burger King, Empire)
			// =================================================================================
			Outlet tacoBellKora = new Outlet("Taco Bell", "Koramangala", "Live Mas", "https://images.unsplash.com/photo-1565299585323-38d6b0865b47?w=800&q=80");
			Outlet burgerKingKora = new Outlet("Burger King", "Koramangala", "Home of the Whopper", "https://images.unsplash.com/photo-1571091718767-18b5b1457add?w=800&q=80");
			Outlet empireKora = new Outlet("Empire", "Koramangala", "Legendary Late Night Eats", "https://images.unsplash.com/photo-1601050690597-df0568f70950?w=800&q=80");

			outletRepository.saveAll(Arrays.asList(tacoBellKora, burgerKingKora, empireKora));

			// --- Taco Bell Menu (9 Items) ---
			menuItemRepository.saveAll(Arrays.asList(
				new MenuItem("Crunchy Taco", 99.00, tacoBellKora),
				new MenuItem("Soft Taco", 99.00, tacoBellKora),
				new MenuItem("7 Layer Burrito", 219.00, tacoBellKora),
				new MenuItem("Chalupa Supreme", 149.00, tacoBellKora),
				new MenuItem("Mexican Pizza", 199.00, tacoBellKora),
				new MenuItem("Naked Chicken Taco", 189.00, tacoBellKora),
				new MenuItem("Cheesy Nachos", 129.00, tacoBellKora),
				new MenuItem("Chocodilla", 79.00, tacoBellKora),
				new MenuItem("Pepsi Fountain", 69.00, tacoBellKora)
			));

			// --- Burger King Menu (9 Items) ---
			menuItemRepository.saveAll(Arrays.asList(
				new MenuItem("Veg Whopper", 169.00, burgerKingKora),
				new MenuItem("Chicken Whopper", 199.00, burgerKingKora),
				new MenuItem("Crispy Veg Burger", 79.00, burgerKingKora),
				new MenuItem("Crispy Chicken Burger", 99.00, burgerKingKora),
				new MenuItem("BK Classic Fries", 99.00, burgerKingKora),
				new MenuItem("Cheesy Fries", 129.00, burgerKingKora),
				new MenuItem("Chicken Fries", 149.00, burgerKingKora),
				new MenuItem("Chocolate Mousse Cup", 89.00, burgerKingKora),
				new MenuItem("Soft Serve Cone", 39.00, burgerKingKora)
			));

			// --- Empire Restaurant Menu (9 Items) ---
			menuItemRepository.saveAll(Arrays.asList(
				new MenuItem("Empire Special Kebab", 250.00, empireKora),
				new MenuItem("Chicken Grill (Half)", 280.00, empireKora),
				new MenuItem("Chicken Biryani", 240.00, empireKora),
				new MenuItem("Mutton Biryani", 290.00, empireKora),
				new MenuItem("Ghee Rice", 140.00, empireKora),
				new MenuItem("Paneer Butter Masala", 210.00, empireKora),
				new MenuItem("Butter Chicken", 260.00, empireKora),
				new MenuItem("Kerala Parotta", 40.00, empireKora),
				new MenuItem("Coin Parotta", 25.00, empireKora)
			));
		}
		
		// 3. Create Users (if they don't exist)
		if(userRepository.count() == 0) {
			User admin = new User("Rishon", passwordEncoder.encode("1234"), "ROLE_ADMIN");
			userRepository.save(admin);
	
			User customer = new User("Johnson", passwordEncoder.encode("1234"), "ROLE_CUSTOMER");
			userRepository.save(customer);
		}
	}
}