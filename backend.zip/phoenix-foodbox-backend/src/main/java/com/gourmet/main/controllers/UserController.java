package com.gourmet.main.controllers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import com.gourmet.main.dtos.UserDTO;
import com.gourmet.main.entities.User;
import com.gourmet.main.repository.UserRepository;
import com.gourmet.main.responses.ApiResponse;
import com.gourmet.main.services.UserService;
import com.gourmet.main.util.JwtUtil;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/user") // Matches your Frontend URL structure
@Validated
public class UserController {

    private static final Logger logger = LoggerFactory.getLogger(UserController.class);

    @Autowired
    private UserService userService;
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private AuthenticationManager authenticationManager;
    
    @Autowired
    private JwtUtil jwtUtil;
    
    @Autowired
    private PasswordEncoder passwordEncoder;

    // 1. ADD USER (Register)
    @PostMapping("/adduser")
    public ResponseEntity<ApiResponse<User>> createUser(@Valid @RequestBody UserDTO userDTO) {
        logger.info("Attempting to create user with username: {}", userDTO.getUsername());
        
        try {
            // Check for Admin Creation Permission
            if ("ROLE_ADMIN".equals(userDTO.getRoles())) {
                if (!isAdmin()) {
                    return ResponseEntity.status(HttpStatus.FORBIDDEN)
                            .body(new ApiResponse<>("Permission denied: You cannot create an Admin.", null));
                }
            }
            
            // Check if user exists
            if(userService.findByUsername(userDTO.getUsername()).isPresent()) {
                 return ResponseEntity.status(HttpStatus.CONFLICT)
                         .body(new ApiResponse<>("Username already exists", null));
            }

            // Create Entity from DTO
            User user = new User();
            user.setUsername(userDTO.getUsername());
            user.setPassword(passwordEncoder.encode(userDTO.getPassword()));
            user.setRoles(userDTO.getRoles());

            // Call Service (Returns User, NOT ResponseEntity)
            User createdUser = userService.saveUser(user);

            // Wrap in Response
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(new ApiResponse<>("User created successfully", createdUser));

        } catch (Exception e) {
            logger.error("Error creating user", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ApiResponse<>("Failed to create user", null));
        }
    }

    // 2. UPDATE USER
    @PutMapping("/updateuser")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<ApiResponse<User>> updateUser(@Valid @RequestBody UserDTO userDTO) {
        try {
            // Convert DTO to User object
            User userUpdate = new User();
            userUpdate.setUsername(userDTO.getUsername());
            userUpdate.setPassword(userDTO.getPassword()); // Service handles encoding
            userUpdate.setRoles(userDTO.getRoles());

            // Call Service
            User updatedUser = userService.updateUser(userDTO.getUser_id(), userUpdate);
            
            return ResponseEntity.ok(new ApiResponse<>("User updated successfully!", updatedUser));

        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new ApiResponse<>(e.getMessage(), null));
        }
    }

    // 3. GET ALL USERS
    @GetMapping("/showuser")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<ApiResponse<List<User>>> getUsers() {
        List<User> users = userService.getAllUsers();
        return ResponseEntity.ok(new ApiResponse<>("Users fetched successfully!", users));
    }
    
    // 4. LOGIN USER
    @PostMapping("/login")
    public ResponseEntity<ApiResponse<Map<String, String>>> loginUser(@RequestBody UserDTO userDTO) {
        try {
            Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(userDTO.getUsername(), userDTO.getPassword())
            );

            if (authentication.isAuthenticated()) {
                // Fetch User details
                UserDetails userDetails = (UserDetails) authentication.getPrincipal();
                User user = userRepository.findByUsername(userDetails.getUsername()).orElseThrow();
                
                // Generate Token
                // Note: Ensure your JwtUtil.generateToken accepts 1 arg (username) 
                // OR 2 args (username, role) depending on your implementation.
                // Assuming standard: generateToken(username)
                String token = jwtUtil.generateToken(user.getUsername()); 
                
                Map<String, String> data = new HashMap<>();
                data.put("token", token);
                data.put("role", user.getRoles());
                data.put("username", user.getUsername());
                
                return ResponseEntity.ok(new ApiResponse<>("Login successful", data));
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                 .body(new ApiResponse<>("Invalid Credentials", null));
        }
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
             .body(new ApiResponse<>("Login Failed", null));
    }

    private boolean isAdmin() {
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if (principal instanceof UserDetails) {
            UserDetails userDetails = (UserDetails) principal;
            return userDetails.getAuthorities().stream()
                    .anyMatch(grantedAuthority -> "ROLE_ADMIN".equals(grantedAuthority.getAuthority()));
        }
        return false;
    }
}