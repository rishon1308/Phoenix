package com.gourmet.main.services;

import java.util.List;
import com.gourmet.main.dtos.MenuItemDTO;
import com.gourmet.main.entities.MenuItem;

public interface MenuItemService {
    MenuItem addFoodItem(MenuItemDTO menuItemDTO);
    
    List<MenuItem> getAllItems();
    
    // NEW: Fetch menu items for a specific outlet
    List<MenuItem> getItemsByOutletId(Long outletId);
    
    MenuItem updateFoodItemById(Long id, MenuItemDTO menuItemDTO);
    void deleteFoodItemById(Long id);
}