package com.gourmet.main.servicesImpl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.gourmet.main.dtos.OutletDTO;
import com.gourmet.main.entities.Outlet;
import com.gourmet.main.repository.OutletRepository;
import com.gourmet.main.services.OutletService;

@Service
public class OutletServiceImpl implements OutletService {

    @Autowired
    private OutletRepository outletRepository;

    @Override
    public Outlet addOutlet(OutletDTO outletDTO) {
        Outlet outlet = new Outlet(
            outletDTO.getOutletName(), 
            outletDTO.getArea(), // Save the Area
            outletDTO.getOutletDescription(), 
            outletDTO.getImageUrl()
        );
        return outletRepository.save(outlet);
    }

    @Override
    public List<Outlet> getAllOutlets() {
        return outletRepository.findAll();
    }

    @Override
    public List<Outlet> getOutletsByArea(String area) {
        return outletRepository.findByAreaIgnoreCase(area);
    }

    @Override
    public Outlet getOutletById(Long id) {
        return outletRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Outlet not found with id: " + id));
    }

    @Override
    public void deleteOutlet(Long id) {
        if (!outletRepository.existsById(id)) {
            throw new RuntimeException("Outlet not found with id: " + id);
        }
        outletRepository.deleteById(id);
    }
}