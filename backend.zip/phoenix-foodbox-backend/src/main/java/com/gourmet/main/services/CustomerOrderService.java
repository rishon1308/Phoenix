package com.gourmet.main.services;

import java.util.List;
import java.util.Map;
import com.gourmet.main.dtos.CustomerOrderDTO;
import com.gourmet.main.entities.CustomerOrder;

public interface CustomerOrderService {
    
    List<CustomerOrder> getAllOrders();
    
    // Admin: View orders for a specific outlet
    List<CustomerOrder> getOrdersByOutletId(Long outletId);

    // Customer: View their own orders
    List<CustomerOrder> getOrdersByUsername(String username);

    CustomerOrder getOrderById(Long id);

    CustomerOrder createOrder(CustomerOrderDTO orderDTO);

    CustomerOrder updateOrderById(Long id, CustomerOrderDTO orderDTO);

    void deleteOrder(Long id);

    // Transform orders for easier frontend display (grouped items)
    List<Map<String, Object>> getAllOrdersForCooks();
}