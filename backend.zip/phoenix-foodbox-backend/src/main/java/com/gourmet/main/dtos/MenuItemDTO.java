package com.gourmet.main.dtos;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class MenuItemDTO {

    private Long id;

    @NotBlank(message = "Food name cannot be empty")
    @Size(min = 3, max = 50, message = "Food name must be between 3 and 50 characters")
    private String foodName;

    @NotNull(message = "Price is required")
    @Min(value = 1, message = "Price must be greater than 0")
    private Double foodPrice;

    // NEW: Added Image URL field so the frontend image link is saved
    private String imageUrl;

    @NotNull(message = "Outlet ID is required")
    private Long outletId;

    // --- Constructors ---

    public MenuItemDTO() {
    }

    public MenuItemDTO(String foodName, Double foodPrice, String imageUrl, Long outletId) {
        this.foodName = foodName;
        this.foodPrice = foodPrice;
        this.imageUrl = imageUrl;
        this.outletId = outletId;
    }

    // --- Getters and Setters ---

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFoodName() {
        return foodName;
    }

    public void setFoodName(String foodName) {
        this.foodName = foodName;
    }

    public Double getFoodPrice() {
        return foodPrice;
    }

    public void setFoodPrice(Double foodPrice) {
        this.foodPrice = foodPrice;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public Long getOutletId() {
        return outletId;
    }

    public void setOutletId(Long outletId) {
        this.outletId = outletId;
    }
}