package com.gourmet.main.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.gourmet.main.entities.Outlet;

@Repository
public interface OutletRepository extends JpaRepository<Outlet, Long> {
    // Finds all outlets in a specific area (Case insensitive is better for search)
    List<Outlet> findByAreaIgnoreCase(String area);
}