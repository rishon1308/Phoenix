package com.gourmet.main.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.Arrays;
import java.util.List;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfig {

    @Autowired
    private UserDetailsService userDetailsService;
    
    @Autowired
    private JwtFilter jwtFilter; // Ensure this class exists in your project

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public AuthenticationManager authenticationManager(
            AuthenticationConfiguration configuration) throws Exception {
        return configuration.getAuthenticationManager();
    }
    
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            // 1. Disable CSRF (Common for stateless JWT APIs)
            .csrf(csrf -> csrf.disable())

            // 2. Enable CORS using our custom configurationSource below
            .cors(cors -> cors.configurationSource(corsConfigurationSource()))

            // 3. Allow H2 Console frames (Optional, kept from your code)
            .headers(headers -> headers.frameOptions(frame -> frame.disable()))

            // 4. Define URL Authorization Rules
            .authorizeHttpRequests(auth -> auth
                // 🔓 PUBLIC ENDPOINTS (No Login Required)
                .requestMatchers(
                    "/user/login",
                    "/api/auth/**",
                    "/user/adduser", 
                    "/menu/view",       // Your legacy endpoint
                    "/api/menu/**",     // <--- NEW: Fixes the Angular menu fetch error
                    "/menu/outlet/**",
                    "/outlets/**",
                    "/h2-console/**",
                    "/error"
                ).permitAll()

                // 🔒 SECURED ENDPOINTS (Login Required)
                .requestMatchers("/api/orders/**").authenticated() 
                .requestMatchers("/api/admin/**").hasRole("ADMIN")

                // Default: All other requests need authentication
                .anyRequest().authenticated()
            )

            // 5. Stateless Session (No cookies, just JWT)
            .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))

            // 6. Add JWT Filter before UsernamePasswordAuthFilter
            .addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }

    // 🌍 CORS CONFIGURATION (Allows Angular on Port 4200)
    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();
        
        // Allow your Angular Frontend URL
        configuration.setAllowedOrigins(List.of("http://localhost:4200")); 
        
        // Allow standard HTTP methods
        configuration.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE", "OPTIONS"));
        
        // Allow all headers (Authorization, Content-Type, etc.)
        configuration.setAllowedHeaders(List.of("*"));
        
        // Allow credentials (needed if sending cookies/auth headers)
        configuration.setAllowCredentials(true);

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration); // Apply to all endpoints
        return source;
    }
}