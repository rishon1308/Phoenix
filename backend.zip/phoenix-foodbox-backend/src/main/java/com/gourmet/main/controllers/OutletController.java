package com.gourmet.main.controllers;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import com.gourmet.main.dtos.OutletDTO;
import com.gourmet.main.entities.Outlet;
import com.gourmet.main.responses.ApiResponse;
import com.gourmet.main.services.OutletService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/outlets")
public class OutletController {

    private static final Logger logger = LoggerFactory.getLogger(OutletController.class);

    @Autowired
    private OutletService outletService;

    // 1. Get All Outlets (For Admin or General List)
    @GetMapping("/all")
    public ResponseEntity<ApiResponse<List<Outlet>>> getAllOutlets() {
        logger.info("Fetching all outlets");
        List<Outlet> outlets = outletService.getAllOutlets();
        return ResponseEntity.ok(new ApiResponse<>("Outlets fetched successfully!", outlets));
    }

    // 2. NEW: Get Outlets by Area (e.g., /outlets/area/Indiranagar)
    @GetMapping("/area/{areaName}")
    public ResponseEntity<ApiResponse<List<Outlet>>> getOutletsByArea(@PathVariable String areaName) {
        logger.info("Fetching outlets in area: {}", areaName);
        List<Outlet> outlets = outletService.getOutletsByArea(areaName);
        return ResponseEntity.ok(new ApiResponse<>("Outlets in " + areaName + " fetched successfully!", outlets));
    }

    // 3. Get Specific Outlet by ID
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<Outlet>> getOutletById(@PathVariable Long id) {
        logger.info("Fetching outlet with ID: {}", id);
        Outlet outlet = outletService.getOutletById(id);
        return ResponseEntity.ok(new ApiResponse<>("Outlet fetched successfully!", outlet));
    }

    // 4. Admin Only: Add new outlet
    @PostMapping("/add")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<ApiResponse<Outlet>> addOutlet(@Valid @RequestBody OutletDTO outletDTO) {
        logger.info("Adding new outlet: {}", outletDTO.getOutletName());
        Outlet outlet = outletService.addOutlet(outletDTO);
        return ResponseEntity.ok(new ApiResponse<>("Outlet added successfully!", outlet));
    }

    // 5. Admin Only: Delete outlet
    @DeleteMapping("/delete/{id}")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<ApiResponse<String>> deleteOutlet(@PathVariable Long id) {
        logger.info("Deleting outlet with ID: {}", id);
        outletService.deleteOutlet(id);
        return ResponseEntity.ok(new ApiResponse<>("Outlet deleted successfully!", null));
    }
}