package com.gourmet.main.dtos;

import java.util.Map;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

public class CustomerOrderDTO {

    @NotBlank(message = "Invalid Name: Cannot be blank!")
    @NotNull(message = "Invalid Name: Cannot be null!")
    @Size(min = 3, max = 30, message = "Invalid Name: Name should be 3 - 30 characters!")
    private String customerName;

    @NotBlank(message = "Invalid Phone number: Empty number!")
    @NotNull(message = "Invalid Phone number: Number is NULL!")
    @Pattern(regexp = "^\\d{10}$", message = "Invalid phone number!")
    private String customerPhoneNumber;

    @NotBlank(message = "Invalid Address: Cannot be blank!")
    @NotNull(message = "Invalid Address: Cannot be null!")
    @Size(min = 10, max = 50, message = "Invalid Address: Address should be 10 - 50 characters!")
    private String customerAddress;

    @NotNull(message = "Order items are required")
    private Map<Long, @Positive @Max(value = 5, message = "Quantity must not exceed 5") Integer> orderItems;
    
    // NEW FIELD: The ID of the outlet being ordered from
    @NotNull(message = "Outlet ID is required")
    private Long outletId;

    public CustomerOrderDTO() {
        super();
    }

    public CustomerOrderDTO(String customerName, String customerPhoneNumber, String customerAddress,
                            Map<Long, Integer> orderItems, Long outletId) {
        this.customerName = customerName;
        this.customerPhoneNumber = customerPhoneNumber;
        this.customerAddress = customerAddress;
        this.orderItems = orderItems;
        this.outletId = outletId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerPhoneNumber() {
        return customerPhoneNumber;
    }

    public void setCustomerPhoneNumber(String customerPhoneNumber) {
        this.customerPhoneNumber = customerPhoneNumber;
    }

    public String getCustomerAddress() {
        return customerAddress;
    }

    public void setCustomerAddress(String customerAddress) {
        this.customerAddress = customerAddress;
    }

    public Map<Long, Integer> getOrderItems() {
        return orderItems;
    }

    public void setOrderItems(Map<Long, Integer> orderItems) {
        this.orderItems = orderItems;
    }

    public Long getOutletId() {
        return outletId;
    }

    public void setOutletId(Long outletId) {
        this.outletId = outletId;
    }
}