package com.gourmet.main.servicesImpl;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional; // Import Transactional

import com.gourmet.main.dtos.CustomerOrderDTO;
import com.gourmet.main.entities.CustomerOrder;
import com.gourmet.main.entities.MenuItem;
import com.gourmet.main.entities.Outlet;
import com.gourmet.main.entities.User;
import com.gourmet.main.repository.CustomerOrderRepository;
import com.gourmet.main.repository.MenuItemRepository;
import com.gourmet.main.repository.OutletRepository;
import com.gourmet.main.repository.UserRepository;
import com.gourmet.main.services.CustomerOrderService;

@Service
public class CustomerOrderServiceImpl implements CustomerOrderService {

    @Autowired private CustomerOrderRepository customerOrderRepository;
    @Autowired private MenuItemRepository menuItemRepository;
    @Autowired private UserRepository userRepository;
    @Autowired private OutletRepository outletRepository;

    @Override
    public CustomerOrder getOrderById(Long id) {
        CustomerOrder order = customerOrderRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Order not found with id: " + id));
        
        // Security Check: Only Admin or Owner can view
        if (!isAdmin() && !order.getUser().getUsername().equals(getCurrentUsername())) {
            throw new RuntimeException("You do not have permission to view this order");
        }
        return order;
    }
    
    @Override
    public List<CustomerOrder> getOrdersByUsername(String username) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found with username: " + username));
        
        // Security Check
        if (!isAdmin() && !user.getUsername().equals(getCurrentUsername())) {
            throw new RuntimeException("Access Denied: You cannot view other users' orders.");
        }
        
        return customerOrderRepository.findByUserOrderByIdDesc(user); // Returns newest first
    }
    
    @Override
    public List<CustomerOrder> getOrdersByOutletId(Long outletId) {
        return customerOrderRepository.findByOutletId(outletId);
    }

    @Override
    @Transactional // Ensure atomic transaction
    public CustomerOrder createOrder(CustomerOrderDTO orderDTO) {
        validateOrderItems(orderDTO.getOrderItems());
        
        // 1. Fetch Outlet
        Outlet outlet = outletRepository.findById(orderDTO.getOutletId())
                .orElseThrow(() -> new RuntimeException("Outlet not found with id: " + orderDTO.getOutletId()));

        // 2. Fetch Menu Items
        List<MenuItem> menuItems = menuItemRepository.findAllById(orderDTO.getOrderItems().keySet());

        // 3. Flatten Items (Create a list of items based on quantity)
        List<MenuItem> orderItems = orderDTO.getOrderItems().entrySet().stream()
            .flatMap(entry -> {
                MenuItem menuItem = menuItems.stream()
                    .filter(item -> item.getId().equals(entry.getKey()))
                    .findFirst()
                    .orElseThrow(() -> new RuntimeException("MenuItem not found: " + entry.getKey()));
                
                return Stream.generate(() -> menuItem).limit(entry.getValue());
            })
            .collect(Collectors.toList());
        
        double totalPrice = orderItems.stream().mapToDouble(MenuItem::getFoodPrice).sum();

        // 4. Build Order
        CustomerOrder order = new CustomerOrder();
        order.setCustomerName(orderDTO.getCustomerName());
        order.setCustomerPhoneNumber(orderDTO.getCustomerPhoneNumber());
        order.setCustomerAddress(orderDTO.getCustomerAddress());
        order.setOrderItems(orderItems);
        order.setTotalPrice(totalPrice);
        order.setOutlet(outlet); 
        order.setUser(getCurrentUser()); // Link to logged-in user
        
        return customerOrderRepository.save(order);
    }

    @Override
    @Transactional // Ensure atomic transaction
    public CustomerOrder updateOrderById(Long id, CustomerOrderDTO orderDTO) {
        CustomerOrder existingOrder = getOrderById(id); // Handles Not Found & Security Check
        
        validateOrderItems(orderDTO.getOrderItems());

        List<MenuItem> menuItems = menuItemRepository.findAllById(orderDTO.getOrderItems().keySet());
        List<MenuItem> orderItems = orderDTO.getOrderItems().entrySet().stream()
            .flatMap(entry -> {
                MenuItem menuItem = menuItems.stream()
                    .filter(item -> item.getId().equals(entry.getKey()))
                    .findFirst()
                    .orElseThrow(() -> new RuntimeException("MenuItem not found: " + entry.getKey()));
                return Stream.generate(() -> menuItem).limit(entry.getValue());
            })
            .collect(Collectors.toList());
        
        double totalPrice = orderItems.stream().mapToDouble(MenuItem::getFoodPrice).sum();

        existingOrder.setCustomerName(orderDTO.getCustomerName());
        existingOrder.setCustomerPhoneNumber(orderDTO.getCustomerPhoneNumber());
        existingOrder.setCustomerAddress(orderDTO.getCustomerAddress());
        
        // Update items and price
        existingOrder.getOrderItems().clear(); // Clear existing list first
        existingOrder.getOrderItems().addAll(orderItems); // Add new items
        existingOrder.setTotalPrice(totalPrice);
        
        return customerOrderRepository.save(existingOrder);
    }

    @Override
    @Transactional // CRITICAL: Transaction needed for proper delete flow
    public void deleteOrder(Long id) {
        CustomerOrder order = getOrderById(id); // Security check included
        
        // 1. Clear the relationship in the Join Table first
        // This prevents ConstraintViolationException
        order.getOrderItems().clear();
        customerOrderRepository.save(order);
        
        // 2. Now delete the order entity
        customerOrderRepository.delete(order);
    }

    @Override
    public List<CustomerOrder> getAllOrders() {
        return customerOrderRepository.findAll();
    }

    // --- HELPER METHODS ---

    @Override
    public List<Map<String, Object>> getAllOrdersForCooks() {
        List<CustomerOrder> orders = customerOrderRepository.findAll();
        return orders.stream().map(order -> {
            Map<String, Object> orderMap = new LinkedHashMap<>();
            orderMap.put("id", order.getId());
            orderMap.put("customerName", order.getCustomerName());
            orderMap.put("customerAddress", order.getCustomerAddress());
            orderMap.put("totalAmount", order.getTotalPrice());
            orderMap.put("location", order.getOutlet() != null ? order.getOutlet().getOutletName() : "General");
            
            // Group duplicate items back into Quantity for display
            orderMap.put("orderItems", order.getOrderItems().stream()
                .collect(Collectors.groupingBy(MenuItem::getId))
                .entrySet().stream().map(entry -> {
                    Map<String, Object> itemMap = new LinkedHashMap<>();
                    // Handle potential empty list (though groupingBy shouldn't allow it)
                    if (!entry.getValue().isEmpty()) {
                        itemMap.put("menuItemName", entry.getValue().get(0).getFoodName());
                        itemMap.put("price", entry.getValue().get(0).getFoodPrice());
                        itemMap.put("quantity", entry.getValue().size());
                    }
                    return itemMap;
                }).collect(Collectors.toList()));
                
            return orderMap;
        }).collect(Collectors.toList());
    }

    private void validateOrderItems(Map<Long, Integer> orderItems) {
        for (Map.Entry<Long, Integer> entry : orderItems.entrySet()) {
            if (entry.getValue() > 20) { // Limit max quantity per item
                throw new IllegalArgumentException("Quantity for item " + entry.getKey() + " is too high (Max 20).");
            }
        }
    }

    private String getCurrentUsername() {
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if (principal instanceof UserDetails) {
            return ((UserDetails) principal).getUsername();
        }
        return principal.toString();
    }

    private User getCurrentUser() {
        return userRepository.findByUsername(getCurrentUsername())
                .orElseThrow(() -> new RuntimeException("Current user not found in DB"));
    }

    private boolean isAdmin() {
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if (principal instanceof UserDetails) {
            return ((UserDetails) principal).getAuthorities().stream()
                    .anyMatch(a -> "ROLE_ADMIN".equals(a.getAuthority()));
        }
        return false;
    }
}