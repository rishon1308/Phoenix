package com.gourmet.main.controllers;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import com.gourmet.main.dtos.MenuItemDTO;
import com.gourmet.main.entities.MenuItem;
import com.gourmet.main.responses.ApiResponse;
import com.gourmet.main.services.MenuItemService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/menu")
public class MenuItemController {

    private static final Logger logger = LoggerFactory.getLogger(MenuItemController.class);

    @Autowired
    private MenuItemService menuItemService;

    @PostMapping("/add")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<ApiResponse<MenuItem>> addFoodItem(@Valid @RequestBody MenuItemDTO menuItemDTO) {
        logger.info("Adding new food item: {} to outlet ID: {}", menuItemDTO.getFoodName(), menuItemDTO.getOutletId());
        MenuItem menuItem = menuItemService.addFoodItem(menuItemDTO);
        ApiResponse<MenuItem> response = new ApiResponse<>("Item added successfully!", menuItem);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/view")
    public ResponseEntity<ApiResponse<List<MenuItem>>> getAllItems() {
        logger.info("Fetching all menu items (global)");
        List<MenuItem> items = menuItemService.getAllItems();
        ApiResponse<List<MenuItem>> response = new ApiResponse<>("Items fetched successfully!", items);
        return ResponseEntity.ok(response);
    }

    // NEW ENDPOINT: Get menu specific to an outlet (e.g., when user clicks "Phoenix Downtown")
    @GetMapping("/outlet/{outletId}")
    public ResponseEntity<ApiResponse<List<MenuItem>>> getItemsByOutlet(@PathVariable Long outletId) {
        logger.info("Fetching menu items for outlet ID: {}", outletId);
        List<MenuItem> items = menuItemService.getItemsByOutletId(outletId);
        ApiResponse<List<MenuItem>> response = new ApiResponse<>("Outlet menu fetched successfully!", items);
        return ResponseEntity.ok(response);
    }

    @PutMapping("/update/{id}")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<ApiResponse<MenuItem>> updateMenuItem(@PathVariable Long id, @Valid @RequestBody MenuItemDTO menuItemDTO) {
        logger.info("Updating menu item with ID: {}", id);
        MenuItem updateMenuItem = menuItemService.updateFoodItemById(id, menuItemDTO);
        ApiResponse<MenuItem> response = new ApiResponse<>("Item updated successfully!", updateMenuItem);
        return ResponseEntity.ok(response);
    }

    @DeleteMapping("/delete/{id}")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<ApiResponse<String>> deleteMenuItem(@PathVariable Long id) {
        logger.info("Deleting menu item with ID: {}", id);
        menuItemService.deleteFoodItemById(id);
        ApiResponse<String> response = new ApiResponse<>("Item deleted successfully!", null);
        return ResponseEntity.ok(response);
    }
}