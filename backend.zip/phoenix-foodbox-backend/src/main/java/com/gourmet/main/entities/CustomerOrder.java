package com.gourmet.main.entities;

import java.util.List;
import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "customer_order")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class CustomerOrder {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "customer_name")
    private String customerName;

    @Column(name = "customer_phone_number")
    private String customerPhoneNumber;

    @Column(name = "customer_address")
    private String customerAddress;

    @ManyToMany
    @JoinTable(name = "customer_order_with_order_items", 
               joinColumns = @JoinColumn(name = "customer_order_id"), 
               inverseJoinColumns = @JoinColumn(name = "order_items_id"))
    @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
    private List<MenuItem> orderItems;

    @Column(name = "total_price")
    private double totalPrice;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id")
    @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
    private User user;

    // NEW: Link to Outlet (so admin knows which outlet received this order)
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "outlet_id")
    @JsonIgnoreProperties({"menuItems", "orders", "hibernateLazyInitializer", "handler"})
    private Outlet outlet;

    public CustomerOrder() {
        super();
    }

    public CustomerOrder(String customerName, String customerPhoneNumber, String customerAddress,
                         List<MenuItem> orderItems, double totalPrice, Outlet outlet) {
        this.customerName = customerName;
        this.customerPhoneNumber = customerPhoneNumber;
        this.customerAddress = customerAddress;
        this.orderItems = orderItems;
        this.totalPrice = totalPrice;
        this.outlet = outlet;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerPhoneNumber() {
        return customerPhoneNumber;
    }

    public void setCustomerPhoneNumber(String customerPhoneNumber) {
        this.customerPhoneNumber = customerPhoneNumber;
    }

    public String getCustomerAddress() {
        return customerAddress;
    }

    public void setCustomerAddress(String customerAddress) {
        this.customerAddress = customerAddress;
    }

    public List<MenuItem> getOrderItems() {
        return orderItems;
    }

    public void setOrderItems(List<MenuItem> orderItems) {
        this.orderItems = orderItems;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Outlet getOutlet() {
        return outlet;
    }

    public void setOutlet(Outlet outlet) {
        this.outlet = outlet;
    }
}