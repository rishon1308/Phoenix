package com.cts.main;
 
import org.springframework.boot.test.context.SpringBootTest;
 
@SpringBootTest
class StudentManagementAppApplicationTests {
 
}