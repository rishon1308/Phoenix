package com.phoenix.foodbox.service;

import com.phoenix.foodbox.model.*;
import com.phoenix.foodbox.repository.OutletRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OutletService {

    @Autowired
    private OutletRepository outletRepository;

    public Outlet addOutlet(Outlet outlet, Franchise franchise, User manager) {
        outlet.setFranchise(franchise);
        outlet.setManager(manager);
        outlet.setActive(false);
        return outletRepository.save(outlet);
    }

    public Outlet activateOutlet(Long outletId) {
        Outlet outlet = outletRepository.findById(outletId)
                .orElseThrow(() -> new RuntimeException("Outlet not found"));
        outlet.setActive(true);
        return outletRepository.save(outlet);
    }

    public List<Outlet> getOutletsByFranchise(Franchise franchise) {
        return outletRepository.findByFranchise(franchise);
    }
}
