package com.phoenix.foodbox.repository;

import com.phoenix.foodbox.model.Slot;
import com.phoenix.foodbox.model.Outlet;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalTime;
import java.util.List;

public interface SlotRepository extends JpaRepository<Slot, Long> {

    List<Slot> findByOutlet(Outlet outlet);

    List<Slot> findByOutletAndStartTimeLessThanEqualAndEndTimeGreaterThanEqual(
            Outlet outlet,
            LocalTime startTime,
            LocalTime endTime
    );
}
