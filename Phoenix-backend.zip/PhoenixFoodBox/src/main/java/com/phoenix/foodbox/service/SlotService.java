package com.phoenix.foodbox.service;

import com.phoenix.foodbox.model.*;
import com.phoenix.foodbox.repository.SlotRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalTime;
import java.util.List;

@Service
public class SlotService {

    @Autowired
    private SlotRepository slotRepository;

    public Slot createSlot(Slot slot, Outlet outlet) {
        slot.setOutlet(outlet);
        slot.setBookedCount(0);
        return slotRepository.save(slot);
    }

    public boolean isSlotAvailable(Slot slot) {
        return slot.getBookedCount() < slot.getCapacity();
    }

    public void incrementSlotBooking(Slot slot) {
        slot.setBookedCount(slot.getBookedCount() + 1);
        slotRepository.save(slot);
    }

    public List<Slot> getSlotsByOutlet(Outlet outlet) {
        return slotRepository.findByOutlet(outlet);
    }
}
