package com.phoenix.foodbox.repository;

import com.phoenix.foodbox.model.Feedback;
import com.phoenix.foodbox.model.Outlet;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface FeedbackRepository extends JpaRepository<Feedback, Long> {

    List<Feedback> findByOutlet(Outlet outlet);
}
