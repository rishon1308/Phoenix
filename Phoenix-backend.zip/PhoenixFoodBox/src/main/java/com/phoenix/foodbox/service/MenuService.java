package com.phoenix.foodbox.service;

import com.phoenix.foodbox.model.*;
import com.phoenix.foodbox.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MenuService {

    @Autowired
    private MenuRepository menuRepository;

    @Autowired
    private MenuItemRepository menuItemRepository;

    public Menu createMenu(Menu menu, Franchise franchise) {
        menu.setFranchise(franchise);
        return menuRepository.save(menu);
    }

    public MenuItem addMenuItem(MenuItem item, Menu menu) {
        item.setMenu(menu);
        item.setAvailable(true);
        return menuItemRepository.save(item);
    }

    public List<Menu> getMenusByFranchise(Franchise franchise) {
        return menuRepository.findByFranchise(franchise);
    }
}
