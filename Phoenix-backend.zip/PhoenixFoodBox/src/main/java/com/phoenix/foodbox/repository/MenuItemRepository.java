package com.phoenix.foodbox.repository;

import com.phoenix.foodbox.model.MenuItem;
import com.phoenix.foodbox.model.Menu;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface MenuItemRepository extends JpaRepository<MenuItem, Long> {

    List<MenuItem> findByMenu(Menu menu);

    List<MenuItem> findByAvailable(boolean available);
}
