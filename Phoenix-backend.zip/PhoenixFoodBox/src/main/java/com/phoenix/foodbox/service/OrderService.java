package com.phoenix.foodbox.service;

import com.phoenix.foodbox.model.*;
import com.phoenix.foodbox.model.enums.OrderStatus;
import com.phoenix.foodbox.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private SlotService slotService;

    public Order placeOrder(
            User customer,
            Outlet outlet,
            Slot slot,
            List<OrderItem> items,
            double totalAmount) {

        if (!slotService.isSlotAvailable(slot)) {
            throw new RuntimeException("Slot is full");
        }

        Order order = new Order();
        order.setCustomer(customer);
        order.setOutlet(outlet);
        order.setSlot(slot);
        order.setItems(items);
        order.setTotalAmount(totalAmount);
        order.setOrderTime(LocalDateTime.now());
        order.setStatus(OrderStatus.PLACED);

        Order savedOrder = orderRepository.save(order);

        slotService.incrementSlotBooking(slot);

        return savedOrder;
    }

    public Order updateOrderStatus(Long orderId, OrderStatus status) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found"));
        order.setStatus(status);
        return orderRepository.save(order);
    }

    public List<Order> getOrdersByOutlet(Outlet outlet) {
        return orderRepository.findByOutlet(outlet);
    }

    public List<Order> getOrdersByCustomer(User customer) {
        return orderRepository.findByCustomer(customer);
    }
}
