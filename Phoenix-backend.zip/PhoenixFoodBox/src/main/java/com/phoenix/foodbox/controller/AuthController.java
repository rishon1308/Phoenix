package com.phoenix.foodbox.controller;

import com.phoenix.foodbox.dto.*;
import com.phoenix.foodbox.model.*;
import com.phoenix.foodbox.model.enums.RoleType;
import com.phoenix.foodbox.repository.*;
import com.phoenix.foodbox.security.JwtUtil;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.*;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Set;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*")
public class AuthController {

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtUtil jwtUtil;

    // ---------------- LOGIN ----------------
    @PostMapping("/login")
    public ResponseEntity<?> authenticateUser(
            @RequestBody LoginRequest loginRequest) {

        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        loginRequest.getEmail(),
                        loginRequest.getPassword()
                )
        );

        SecurityContextHolder.getContext().setAuthentication(authentication);

        String jwt = jwtUtil.generateToken(loginRequest.getEmail());

        User user = userRepository.findByEmail(loginRequest.getEmail()).get();

        List<String> roles = user.getRoles()
                .stream()
                .map(r -> r.getRoleType().name())
                .toList();

        return ResponseEntity.ok(
                new JwtResponse(jwt, user.getEmail(), roles)
        );
    }

    // ---------------- REGISTER ----------------
    @PostMapping("/register")
    public ResponseEntity<?> registerUser(
            @RequestBody SignupRequest signupRequest) {

        if (userRepository.existsByEmail(signupRequest.getEmail())) {
            return ResponseEntity
                    .badRequest()
                    .body("Error: Email already exists");
        }

        User user = new User();
        user.setName(signupRequest.getName());
        user.setEmail(signupRequest.getEmail());
        user.setPassword(
                passwordEncoder.encode(signupRequest.getPassword())
        );

        Role role = roleRepository
                .findByRoleType(signupRequest.getRole())
                .orElseThrow(() ->
                        new RuntimeException("Role not found")
                );

        user.setRoles(Set.of(role));

        userRepository.save(user);

        return ResponseEntity.ok("User registered successfully");
    }
}
