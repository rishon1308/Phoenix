package com.phoenix.foodbox.model;

import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name = "outlets")
public class Outlet {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String outletName;
    private String location;

    private boolean active;

    private int maxOrdersPerSlot;

    @ManyToOne
    private Franchise franchise;

    @ManyToOne
    private User manager;

    @OneToMany(mappedBy = "outlet")
    private List<Slot> slots;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getOutletName() {
		return outletName;
	}

	public void setOutletName(String outletName) {
		this.outletName = outletName;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public int getMaxOrdersPerSlot() {
		return maxOrdersPerSlot;
	}

	public void setMaxOrdersPerSlot(int maxOrdersPerSlot) {
		this.maxOrdersPerSlot = maxOrdersPerSlot;
	}

	public Franchise getFranchise() {
		return franchise;
	}

	public void setFranchise(Franchise franchise) {
		this.franchise = franchise;
	}

	public User getManager() {
		return manager;
	}

	public void setManager(User manager) {
		this.manager = manager;
	}

	public List<Slot> getSlots() {
		return slots;
	}

	public void setSlots(List<Slot> slots) {
		this.slots = slots;
	}

    // getters & setters
}
