package com.phoenix.foodbox.controller;

import com.phoenix.foodbox.model.Franchise;
import com.phoenix.foodbox.service.FranchiseService;
import com.phoenix.foodbox.service.OutletService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/admin")
@CrossOrigin(origins = "http://localhost:4200")
public class AdminController {

    @Autowired
    private FranchiseService franchiseService;

    @Autowired
    private OutletService outletService;

    // Approve franchise
    @PutMapping("/approve/franchise/{id}")
    public Franchise approveFranchise(@PathVariable Long id) {
        return franchiseService.approveFranchise(id);
    }

    //  Activate outlet
    @PutMapping("/activate/outlet/{id}")
    public String activateOutlet(@PathVariable Long id) {
        outletService.activateOutlet(id);
        return "Outlet activated";
    }
}
