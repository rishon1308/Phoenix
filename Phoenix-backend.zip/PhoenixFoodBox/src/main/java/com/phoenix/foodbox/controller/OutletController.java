package com.phoenix.foodbox.controller;

import com.phoenix.foodbox.model.enums.OrderStatus;
import com.phoenix.foodbox.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/outlet")
@CrossOrigin(origins = "http://localhost:4200")
public class OutletController {

    @Autowired
    private OrderService orderService;

    //  Update order status
    @PutMapping("/order/{orderId}/status")
    public String updateOrderStatus(
            @PathVariable Long orderId,
            @RequestParam OrderStatus status) {

        orderService.updateOrderStatus(orderId, status);
        return "Order status updated";
    }
}
