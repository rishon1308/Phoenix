package com.phoenix.foodbox.model.enums;

public enum BookingType {
    DINE_IN,
    TAKEAWAY,
    SCHEDULED
}
