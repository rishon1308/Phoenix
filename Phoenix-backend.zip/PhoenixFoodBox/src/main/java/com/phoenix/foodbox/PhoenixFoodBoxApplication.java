package com.phoenix.foodbox;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PhoenixFoodBoxApplication {

	public static void main(String[] args) {
		SpringApplication.run(PhoenixFoodBoxApplication.class, args);
	}

}
