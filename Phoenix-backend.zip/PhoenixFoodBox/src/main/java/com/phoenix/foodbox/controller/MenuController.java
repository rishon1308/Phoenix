package com.phoenix.foodbox.controller;

import com.phoenix.foodbox.model.*;
import com.phoenix.foodbox.service.MenuService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/menu")
@CrossOrigin(origins = "http://localhost:4200")
public class MenuController {

    @Autowired
    private MenuService menuService;

    //  Create menu
    @PostMapping("/create")
    public Menu createMenu(
            @RequestBody Menu menu,
            @RequestParam Long franchiseId) {

        Franchise franchise = new Franchise();
        franchise.setId(franchiseId);
        return menuService.createMenu(menu, franchise);
    }

    //  Add menu item
    @PostMapping("/item")
    public MenuItem addMenuItem(
            @RequestBody MenuItem item,
            @RequestParam Long menuId) {

        Menu menu = new Menu();
        menu.setId(menuId);
        return menuService.addMenuItem(item, menu);
    }

    // View menus
    @GetMapping("/franchise/{franchiseId}")
    public List<Menu> getMenus(@PathVariable Long franchiseId) {
        Franchise franchise = new Franchise();
        franchise.setId(franchiseId);
        return menuService.getMenusByFranchise(franchise);
    }
}
