package com.phoenix.foodbox.repository;

import com.phoenix.foodbox.model.Outlet;
import com.phoenix.foodbox.model.Franchise;
import com.phoenix.foodbox.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface OutletRepository extends JpaRepository<Outlet, Long> {

    List<Outlet> findByFranchise(Franchise franchise);

    List<Outlet> findByActive(boolean active);

    List<Outlet> findByManager(User manager);
}
