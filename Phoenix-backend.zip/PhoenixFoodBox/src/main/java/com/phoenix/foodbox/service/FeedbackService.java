package com.phoenix.foodbox.service;

import com.phoenix.foodbox.model.*;
import com.phoenix.foodbox.repository.FeedbackRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FeedbackService {

    @Autowired
    private FeedbackRepository feedbackRepository;

    public Feedback submitFeedback(
            User customer,
            Outlet outlet,
            int rating,
            String comment) {

        Feedback feedback = new Feedback();
        feedback.setCustomer(customer);
        feedback.setOutlet(outlet);
        feedback.setRating(rating);
        feedback.setComment(comment);

        return feedbackRepository.save(feedback);
    }

    public List<Feedback> getFeedbackForOutlet(Outlet outlet) {
        return feedbackRepository.findByOutlet(outlet);
    }
}
