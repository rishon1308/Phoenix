package com.phoenix.foodbox.model.enums;

public enum RoleType {
    CUSTOMER,
    FRANCHISE_OWNER,
    OUTLET_MANAGER,
    ADMIN
}
