package com.phoenix.foodbox.config;

import com.phoenix.foodbox.model.Role;
import com.phoenix.foodbox.model.enums.RoleType;
import com.phoenix.foodbox.repository.RoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RoleSeeder implements CommandLineRunner {

    @Autowired
    private RoleRepository roleRepository;

    @Override
    public void run(String... args) {

        for (RoleType roleType : RoleType.values()) {
            roleRepository.findByRoleType(roleType)
                    .orElseGet(() -> {
                        Role role = new Role();
                        role.setRoleType(roleType);
                        return roleRepository.save(role);
                    });
        }

        System.out.println("✔ Roles seeded successfully");
    }
}