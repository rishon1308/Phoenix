package com.phoenix.foodbox.controller;

import com.phoenix.foodbox.model.*;
import com.phoenix.foodbox.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/customer")
@CrossOrigin(origins = "http://localhost:4200")
public class CustomerController {

    @Autowired
    private FranchiseService franchiseService;

    @Autowired
    private OutletService outletService;

    @Autowired
    private SlotService slotService;

    @Autowired
    private OrderService orderService;

    // View approved franchises
    @GetMapping("/franchises")
    public List<Franchise> getFranchises() {
        return franchiseService.getApprovedFranchises();
    }

    // View outlets of a franchise
    @GetMapping("/outlets/{franchiseId}")
    public List<Outlet> getOutlets(@PathVariable Long franchiseId) {
        Franchise f = new Franchise();
        f.setId(franchiseId);
        return outletService.getOutletsByFranchise(f);
    }

    // View slots of an outlet
    @GetMapping("/slots/{outletId}")
    public List<Slot> getSlots(@PathVariable Long outletId) {
        Outlet outlet = new Outlet();
        outlet.setId(outletId);
        return slotService.getSlotsByOutlet(outlet);
    }

    // View orders of logged-in customer
    @GetMapping("/orders")
    public List<Order> getCustomerOrders(@RequestParam String email) {
        User user = new User();
        user.setEmail(email);
        return orderService.getOrdersByCustomer(user);
    }
}
