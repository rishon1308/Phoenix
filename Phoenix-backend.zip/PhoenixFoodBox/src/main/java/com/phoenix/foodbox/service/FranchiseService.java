package com.phoenix.foodbox.service;

import com.phoenix.foodbox.model.Franchise;
import com.phoenix.foodbox.model.User;
import com.phoenix.foodbox.repository.FranchiseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FranchiseService {

    @Autowired
    private FranchiseRepository franchiseRepository;

    public Franchise createFranchise(Franchise franchise, User owner) {
        franchise.setOwner(owner);
        franchise.setApproved(false);
        return franchiseRepository.save(franchise);
    }

    public List<Franchise> getApprovedFranchises() {
        return franchiseRepository.findByApproved(true);
    }

    public Franchise approveFranchise(Long id) {
        Franchise franchise = franchiseRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Franchise not found"));
        franchise.setApproved(true);
        return franchiseRepository.save(franchise);
    }
}
