package com.phoenix.foodbox.model.enums;

public enum OrderStatus {
    PLACED,
    ACCEPTED,
    IN_PROGRESS,
    READY,
    COMPLETED,
    CANCELLED
}
