package com.phoenix.foodbox.repository;

import com.phoenix.foodbox.model.Franchise;
import com.phoenix.foodbox.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface FranchiseRepository extends JpaRepository<Franchise, Long> {

    List<Franchise> findByApproved(boolean approved);

    List<Franchise> findByOwner(User owner);
}
