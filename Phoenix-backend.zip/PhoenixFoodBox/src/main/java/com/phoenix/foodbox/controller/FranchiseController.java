package com.phoenix.foodbox.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.phoenix.foodbox.model.Franchise;
import com.phoenix.foodbox.model.Outlet;
import com.phoenix.foodbox.model.User;
import com.phoenix.foodbox.service.FranchiseService;
import com.phoenix.foodbox.service.OutletService;

@RestController
@RequestMapping("/api/franchise")
@CrossOrigin(origins = "http://localhost:4200")
public class FranchiseController {

    @Autowired
    private FranchiseService franchiseService;

    @Autowired
    private OutletService outletService;

    // Register franchise
    @PostMapping("/register")
    public Franchise registerFranchise(
            @RequestBody Franchise franchise,
            @RequestParam String ownerEmail) {

        User owner = new User();
        owner.setEmail(ownerEmail);
        return franchiseService.createFranchise(franchise, owner);
    }

    //  Add outlet
    @PostMapping("/outlet")
    public Outlet addOutlet(
            @RequestBody Outlet outlet,
            @RequestParam Long franchiseId,
            @RequestParam String managerEmail) {

        Franchise franchise = new Franchise();
        franchise.setId(franchiseId);

        User manager = new User();
        manager.setEmail(managerEmail);

        return outletService.addOutlet(outlet, franchise, manager);
    }
}
