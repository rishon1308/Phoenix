import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, tap } from 'rxjs';
import { User, ApiResponse } from '../models/models';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  // Updated to match the SecurityConfig paths
  private baseUrl = 'http://localhost:8082/api/auth';

  constructor(private http: HttpClient, private router: Router) {}

  // --- 1. REGISTER (Customer) ---
  register(user: User): Observable<ApiResponse<string>> {
    return this.http.post<ApiResponse<string>>(`${this.baseUrl}/register`, user);
  }

  // --- 2. LOGIN ---
  login(user: User): Observable<ApiResponse<any>> {
    return this.http.post<ApiResponse<any>>(`${this.baseUrl}/login`, user).pipe(
      tap((response) => {
        // Backend returns: { data: { token: "...", username: "...", role: "..." } }
        if (response && response.data) {
          const { token, username, role } = response.data;
          
          // Save critical data to Local Storage
          if(token) localStorage.setItem('token', token);
          if(username) localStorage.setItem('username', username);
          if(role) localStorage.setItem('role', role);
        }
      })
    );
  }

  // --- 3. CREATE ADMIN (Protected Route) ---
  createAdmin(user: User): Observable<ApiResponse<string>> {
    // Requires existing Admin Token to create another Admin
    const headers = this.getAuthHeaders(); 
    return this.http.post<ApiResponse<string>>(
      `${this.baseUrl}/create-admin`, 
      user, 
      { headers }
    );
  }

  // --- 4. LOGOUT ---
  logout(): void {
    localStorage.clear(); // Wipes Token, Username, Role
    this.router.navigate(['/login']);
  }

  // --- 5. HELPER METHODS ---

  getToken(): string | null {
    return localStorage.getItem('token');
  }

  getUsername(): string | null {
    return localStorage.getItem('username');
  }

  getRole(): string | null {
    return localStorage.getItem('role');
  }

  isLoggedIn(): boolean {
    return !!this.getToken();
  }

  isAdmin(): boolean {
    const role = this.getRole();
    return role === 'ROLE_ADMIN';
  }

  // --- 6. AUTH HEADER GENERATOR ---
  // Services use this to attach the "Bearer <token>" header
  getAuthHeaders(): HttpHeaders {
    const token = this.getToken();
    if (token) {
      return new HttpHeaders({
        'Authorization': `Bearer ${token}`
      });
    }
    return new HttpHeaders();
  }
}