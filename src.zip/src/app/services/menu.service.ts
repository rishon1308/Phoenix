import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import {
  MenuItem,
  ApiResponse,
  OrderRequest, // Ensure this matches your models.ts
  CustomerOrder,
} from '../models/models';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root',
})
export class MenuService {
  // Base Backend URL
  private baseUrl = 'http://localhost:8082';

  // Pexels API Key
  private PEXELS_API_KEY =
    'FdMFbn8GyN0ud5DoVrGCbgc79osckWiESupQuC7ipZmFfDS301HCBO2V';

  constructor(private http: HttpClient, private authService: AuthService) {}

  // --- HELPER: Get Headers with Token ---
  private getAuthHeaders() {
    const token = this.authService.getToken();
    return {
      headers: new HttpHeaders({
        'Authorization': `Bearer ${token}`
      })
    };
  }

  // --- MENU OPERATIONS ---

  // 1. Get All Items (Global View)
  getMenuItems(): Observable<ApiResponse<MenuItem[]>> {
    return this.http.get<ApiResponse<MenuItem[]>>(`${this.baseUrl}/menu/view`);
  }

  // 2. NEW: Get Menu by Outlet ID (For Specific Restaurant Page)
  getMenuByOutlet(outletId: number | string): Observable<ApiResponse<MenuItem[]>> {
    return this.http.get<ApiResponse<MenuItem[]>>(`${this.baseUrl}/menu/outlet/${outletId}`);
  }

  // 3. Admin: Add Item
  addMenuItem(item: any): Observable<ApiResponse<MenuItem>> {
    return this.http.post<ApiResponse<MenuItem>>(
      `${this.baseUrl}/menu/add`, 
      item, 
      this.getAuthHeaders()
    );
  }

  // 4. Admin: Update Item
  updateMenuItem(id: number, item: any): Observable<ApiResponse<MenuItem>> {
    return this.http.put<ApiResponse<MenuItem>>(
      `${this.baseUrl}/menu/update/${id}`,
      item,
      this.getAuthHeaders()
    );
  }

  // 5. Admin: Delete Item
  deleteMenuItem(id: number): Observable<ApiResponse<string>> {
    return this.http.delete<ApiResponse<string>>(
      `${this.baseUrl}/menu/delete/${id}`,
      this.getAuthHeaders()
    );
  }

  // --- ORDER OPERATIONS ---

  // 1. Place Order
  placeOrder(order: any): Observable<ApiResponse<string>> {
    return this.http.post<ApiResponse<string>>(
      `${this.baseUrl}/api/orders/place`, 
      order, 
      this.getAuthHeaders()
    );
  }

  // 2. Get My Orders (Customer)
  // Note: We keep the 'username' param to match your component code, 
  // but the backend actually uses the Token to identify the user.
  getOrdersByUsername(username: string): Observable<ApiResponse<CustomerOrder[]>> {
    return this.http.get<ApiResponse<CustomerOrder[]>>(
      `${this.baseUrl}/api/orders/my-orders`, 
      this.getAuthHeaders()
    );
  }

  // 3. Get ALL Orders (Admin)
  getAllOrders(): Observable<ApiResponse<CustomerOrder[]>> {
    return this.http.get<ApiResponse<CustomerOrder[]>>(
      `${this.baseUrl}/api/orders/all`, 
      this.getAuthHeaders()
    );
  }

  // 4. Delete Order
  deleteOrder(id: number): Observable<ApiResponse<string>> {
    return this.http.delete<ApiResponse<string>>(
      `${this.baseUrl}/api/orders/delete/${id}`,
      this.getAuthHeaders()
    );
  }

  // --- EXTERNAL API (PEXELS) ---
  fetchImageFromPexels(query: string): Observable<any> {
    return this.http.get(
      `https://api.pexels.com/v1/search?query=${query}&per_page=1`,
      {
        headers: { Authorization: this.PEXELS_API_KEY },
      }
    );
  }
}