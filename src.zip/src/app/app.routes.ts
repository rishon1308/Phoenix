import { Routes } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { LoginComponent } from './components/common/login/login.component';
import { RegisterComponent } from './components/common/register/register.component';
import { MenuComponent } from './components/menu/menu.component';
import { MyOrdersComponent } from './components/my-orders/my-orders.component';
import { AllOrdersComponent } from './components/all-orders/all-orders.component';
import { AdminComponent } from './components/admin/admin.component';
 // Ensure path is correct

// Import the guards
import { authGuard, adminGuard } from './guards/auth.guard';
import { RestaurantListComponent } from './restaurant-list/restaurant-list';

export const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },

  // NEW: Shows list of restaurants in an area (e.g., /outlets/Indiranagar)
  { path: 'outlets/:area', component: RestaurantListComponent },

  // UPDATED: Shows menu for a specific restaurant ID (e.g., /menu/5)
  // We removed the generic 'menu' route because users must pick a restaurant now.
  { path: 'menu/:outletId', component: MenuComponent },

  // Protect "My Orders" -> User must be logged in
  {
    path: 'my-orders',
    component: MyOrdersComponent,
    canActivate: [authGuard],
  },

  // Protect "All Orders" -> User must be ADMIN
  {
    path: 'all-orders',
    component: AllOrdersComponent,
    canActivate: [adminGuard],
  },

  // Protect "Admin Dashboard" -> User must be ADMIN
  {
    path: 'admin',
    component: AdminComponent,
    canActivate: [adminGuard],
  },

  // Fallback for invalid URLs
  { path: '**', redirectTo: '' }
];