import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { AuthService } from '../../../services/auth.service';
import { User } from '../../../models/models';
import { ToastrService } from 'ngx-toastr';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatFormFieldModule, // Critical for the input boxes to look right
    MatCardModule,
    MatInputModule,
    MatButtonModule,
    RouterModule,
    MatIconModule
  ],
  templateUrl: './login.component.html',
  // CHANGED: Use styleUrls to link the CSS file instead of inline styles
  styleUrls: ['./login.component.css'] 
})
export class LoginComponent {
  user: User = { username: '', password: '', roles: 'ROLE_CUSTOMER' }; 
  errorMsg: string = '';

  constructor(
    private authService: AuthService,
    private router: Router,
    private toastr: ToastrService
  ) {}

  onLogin() {
    this.authService.login(this.user).subscribe({
      next: (response) => {
        this.toastr.success('Login Successful!', 'Welcome');
        setTimeout(() => this.router.navigate(['/']), 1000);
      },
      error: (err) => {
        if (err.error && err.error.status) {
          this.errorMsg = err.error.status;
        } else {
          this.errorMsg = 'Login failed. Please check your credentials.';
        }
        this.toastr.error(this.errorMsg);
      },
    });
  }
}