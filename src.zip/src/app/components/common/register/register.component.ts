import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field'; 
import { ToastrService } from 'ngx-toastr';

// FIX 1: Corrected Paths (Up 3 levels: register -> common -> components -> app)
import { AuthService } from '../../../services/auth.service';
import { User } from '../../../models/models';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatCardModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatFormFieldModule, 
    RouterModule
  ],
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
  
  user: User = { username: '', password: '', roles: 'ROLE_CUSTOMER' };
  errorMsg: string = '';
  validationErrors: any = {}; 

  constructor(
    private authService: AuthService,
    private router: Router,
    private toastr: ToastrService
  ) {}

  onRegister() {
    this.validationErrors = {};
    this.errorMsg = '';

    this.authService.register(this.user).subscribe({
      next: () => {
        this.toastr.success('Account created! Redirecting to login...');
        setTimeout(() => this.router.navigate(['/login']), 1500);
      },
      // FIX 2: Explicitly added ': any' type to 'err'
      error: (err: any) => {
        console.error(err);
        
        // Handle Validation Errors (400)
        if (err.status === 400 && err.error && err.error.data) {
          this.validationErrors = err.error.data; 
          this.toastr.error('Please fix the errors below.');
        }
        // Handle User Exists (409)
        else if (err.status === 409) {
          this.errorMsg = err.error.message || 'Username already exists.';
        } 
        // Generic Error
        else {
          this.errorMsg = 'Registration failed. Please try again later.';
        }
      },
    });
  }
}