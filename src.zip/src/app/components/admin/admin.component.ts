import { Component, OnInit, NgZone, ChangeDetectorRef } from '@angular/core'; // Import NgZone & CDR
import { CommonModule } from '@angular/common';
import { MatTabsModule } from '@angular/material/tabs';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTableModule } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';
import { MenuService } from '../../services/menu.service';

@Component({
  selector: 'app-admin',
  standalone: true,
  imports: [
    CommonModule,
    MatTabsModule,
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    MatTableModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    FormsModule,
    ReactiveFormsModule
  ],
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  
  // Data for Selectors
  outlets: any[] = [];
  
  // Forms
  menuForm: FormGroup;
  
  // Tables Data
  menuItems: any[] = [];
  allOrders: any[] = [];

  // Table Columns
  menuColumns: string[] = ['id', 'image', 'name', 'price', 'outlet', 'actions'];
  orderColumns: string[] = ['id', 'customer', 'outlet', 'items', 'total', 'actions'];

  constructor(
    private fb: FormBuilder,
    private http: HttpClient,
    private menuService: MenuService,
    private toastr: ToastrService,
    private ngZone: NgZone,       // <--- Inject
    private cdr: ChangeDetectorRef // <--- Inject
  ) {
    this.menuForm = this.fb.group({
      foodName: ['', Validators.required],
      foodPrice: ['', Validators.required],
      imageUrl: [''],
      outletId: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    // Load all data on init
    this.fetchOutlets();
    this.fetchOrders();
    this.fetchMenuItems(); 
  }

  // --- HELPER: Fixes NG0100 Error ---
  private runInZone(callback: () => void) {
    this.ngZone.run(() => {
      setTimeout(() => {
        callback();
        this.cdr.detectChanges(); // Force screen update
      }, 0);
    });
  }

  // --- 1. FETCH DATA ---

  fetchOutlets() {
    this.http.get<any>('http://localhost:8082/outlets/all').subscribe({
      next: (res) => {
        this.runInZone(() => {
          this.outlets = res.data || res;
        });
      },
      error: () => this.toastr.error('Failed to load outlets')
    });
  }

  fetchOrders() {
    this.menuService.getAllOrders().subscribe({
      next: (res: any) => {
        this.runInZone(() => {
          this.allOrders = res.data || res || [];
          // Sort by ID desc (Newest first)
          this.allOrders.sort((a, b) => b.id - a.id);
        });
      },
      error: (err) => {
        this.runInZone(() => {
          console.error("Orders Error:", err);
          // Don't show toast immediately if it's just empty, let the UI handle it
          if (err.status === 403) this.toastr.error('Admin Access Required');
        });
      }
    });
  }

  fetchMenuItems() {
    this.menuService.getMenuItems().subscribe({
      next: (res: any) => {
        this.runInZone(() => {
          this.menuItems = res.data || res || [];
        });
      }
    });
  }

  // --- 2. MENU MANAGEMENT ---

  // In admin.component.ts

  addMenuItem() {
    if (this.menuForm.invalid) {
      this.toastr.warning('Please fill all fields');
      return;
    }

    const formValue = this.menuForm.value;
    
    // Simple, flat payload matching MenuItemDTO in Java
    const finalPayload = {
        foodName: formValue.foodName,
        foodPrice: formValue.foodPrice,
        imageUrl: formValue.imageUrl,
        outletId: formValue.outletId // Send the ID directly now!
    };

    this.menuService.addMenuItem(finalPayload).subscribe({
      next: () => {
        this.runInZone(() => {
          this.toastr.success('Item Added Successfully!');
          this.menuForm.reset();
          this.menuForm.get('outletId')?.setErrors(null);
          this.fetchMenuItems();
        });
      },
      error: (err) => {
        this.runInZone(() => {
          console.error(err);
          this.toastr.error('Failed to add item');
        });
      }
    });
  }

  deleteItem(id: number) {
    if(!confirm('Delete this item?')) return;
    this.menuService.deleteMenuItem(id).subscribe({
      next: () => {
        this.runInZone(() => {
          this.toastr.success('Item deleted');
          this.fetchMenuItems();
        });
      },
      error: () => this.toastr.error('Could not delete item')
    });
  }

  // --- 3. ORDER MANAGEMENT ---

  deleteOrder(id: number) {
    if(!confirm('Cancel this order?')) return;
    this.menuService.deleteOrder(id).subscribe({
      next: () => {
        this.runInZone(() => {
          this.toastr.success('Order cancelled');
          this.fetchOrders();
        });
      },
      error: () => this.toastr.error('Failed to cancel order')
    });
  }
}