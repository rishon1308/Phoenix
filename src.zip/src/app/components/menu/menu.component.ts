import { Component, OnInit, NgZone, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router'; 
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatCardModule } from '@angular/material/card';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';

// Services & Models
import { AuthService } from '../../services/auth.service';
import { MenuItem } from '../../models/models';

interface CartItem extends MenuItem {
  qty: number;
}

@Component({
  selector: 'app-menu',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatButtonModule,
    MatIconModule,
    MatInputModule,
    MatFormFieldModule,
    MatSnackBarModule,
    MatCardModule,
    MatProgressSpinnerModule
  ],
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {
  
  menuItems: MenuItem[] = [];
  cartItems: CartItem[] = [];
  isLoading: boolean = true;
  
  outletId: string | null = null;
  restaurantName: string = 'Menu'; 

  customerName: string = '';
  customerPhone: string = '';
  customerAddress: string = '';

  constructor(
    private http: HttpClient, 
    private snackBar: MatSnackBar,
    private route: ActivatedRoute,
    private router: Router,
    private cdr: ChangeDetectorRef,
    private ngZone: NgZone,
    private authService: AuthService 
  ) {}

  ngOnInit(): void {
    this.outletId = this.route.snapshot.paramMap.get('outletId');
    
    if (this.outletId) {
      this.fetchMenu(this.outletId);
    } else {
      this.showSnack('Invalid Restaurant Selection', 'error');
      this.router.navigate(['/']);
    }
  }

  fetchMenu(id: string) {
    this.isLoading = true;

    this.http.get<any>(`http://localhost:8082/menu/outlet/${id}`)
      .subscribe({
        next: (response) => {
          this.runInZone(() => {
            let rawData: any[] = [];
            if (response && response.data) rawData = response.data;
            else if (Array.isArray(response)) rawData = response;

            this.menuItems = rawData.map(item => {
               const resName = (item.outlet && item.outlet.outletName) 
                             ? item.outlet.outletName 
                             : 'Restaurant';
               
               if (resName !== 'Restaurant') this.restaurantName = resName;

               return {
                id: item.id,
                foodName: item.foodName || item.name || 'Unknown',
                foodPrice: item.foodPrice || item.price || 0,
                imageUrl: item.imageUrl || `https://placehold.co/400?text=${encodeURIComponent(item.foodName || 'Food')}`,
                location: resName
              };
            });

            this.isLoading = false;
          });
        },
        error: (err) => {
          this.runInZone(() => {
            console.error('❌ Error loading menu:', err);
            this.isLoading = false;
            this.showSnack('Could not load menu items.', 'error');
          });
        }
      });
  }

  // --- Helper to fix NG0100 Error ---
  // Wraps updates in setTimeout to wait for view rendering to finish
  private runInZone(callback: () => void) {
    this.ngZone.run(() => {
      setTimeout(() => {
        callback();
        this.cdr.detectChanges();
      }, 0);
    });
  }

  // --- Cart Logic ---
  addToCart(item: MenuItem) {
    const existing = this.cartItems.find(c => c.id === item.id);
    if (existing) {
      existing.qty++;
    } else {
      this.cartItems.push({ ...item, qty: 1 });
    }
  }

  removeFromCart(item: MenuItem) {
    const existing = this.cartItems.find(c => c.id === item.id);
    if (existing) {
      existing.qty--;
      if (existing.qty === 0) {
        this.cartItems = this.cartItems.filter(c => c.id !== item.id);
      }
    }
  }

  getQty(itemId: number): number {
    const item = this.cartItems.find(c => c.id === itemId);
    return item ? item.qty : 0;
  }

  getTotal(): number {
    return this.cartItems.reduce((acc, item) => acc + (item.foodPrice * item.qty), 0);
  }

  // --- Checkout Logic (FIXED) ---
  placeOrder() {
    console.log("🚀 Attempting to place order...");

    if (this.cartItems.length === 0) {
      this.showSnack('Cart is empty!', 'warning');
      return;
    }

    const token = this.authService.getToken();
    if (!token) {
      this.showSnack('Please login to place an order', 'error');
      this.router.navigate(['/login']); 
      return;
    }

    if (!this.customerName || !this.customerPhone || !this.customerAddress) {
      this.showSnack('Fill all details!', 'warning');
      return;
    }

    // 1. Construct Payload carefully
    const orderItemsMap: any = {};
    this.cartItems.forEach(item => {
      orderItemsMap[item.id] = item.qty;
    });

    // Ensure outletId is a pure number
    const finalOutletId = this.outletId ? parseInt(this.outletId, 10) : null;

    const orderPayload = {
      customerName: this.customerName,
      customerPhoneNumber: this.customerPhone, // Ensure backend validation passes (e.g., 10 digits)
      customerAddress: this.customerAddress,
      outletId: finalOutletId, 
      orderItems: orderItemsMap
    };

    // DEBUG: Print payload to console to check for errors
    console.log("📦 PAYLOAD TO BACKEND:", JSON.stringify(orderPayload, null, 2));

    this.isLoading = true;

    const headers = new HttpHeaders({
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    });

    this.http.post('http://localhost:8082/api/orders/place', orderPayload, { headers })
      .subscribe({
        next: (res) => {
          this.runInZone(() => {
            console.log("✅ Order Success:", res);
            this.isLoading = false;
            this.showSnack('Order placed successfully!', 'success');
            
            this.cartItems = [];
            this.customerName = ''; 
            this.customerPhone = ''; 
            this.customerAddress = '';
            
            this.router.navigate(['/my-orders']);
          });
        },
        error: (err) => {
          this.runInZone(() => {
            this.isLoading = false;
            console.error("❌ Order Failed:", err);

            // Handle Specific 400 Bad Request Errors
            if (err.status === 400) {
              this.showSnack('Invalid Data. Check Phone Number & Fields.', 'error');
            } else if (err.status === 403) {
              this.showSnack('Session expired. Login again.', 'error');
            } else {
              this.showSnack('Failed to place order. Check Console.', 'error');
            }
          });
        }
      });
  }

  private showSnack(msg: string, type: 'success' | 'error' | 'warning') {
    this.snackBar.open(msg, 'Close', {
      duration: 3000,
      panelClass: type === 'error' ? ['snackbar-error'] : ['snackbar-success']
    });
  }
}