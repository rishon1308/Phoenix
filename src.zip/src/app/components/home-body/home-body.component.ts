import { Component, ElementRef, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';

interface AreaSlide {
  name: string;      // Matches your Backend Area Name
  location: string;  // Display text (e.g., "Bengaluru")
  image: string;     // Background Image
  tagline: string;   // Marketing text
}

@Component({
  selector: 'app-home-body',
  standalone: true,
  imports: [CommonModule, MatIconModule, MatButtonModule],
  templateUrl: './home-body.component.html',
  styleUrl: './home-body.component.css',
})
export class HomeBodyComponent {
  @ViewChild('outletSection') outletSection!: ElementRef;

  currentIndex: number = 0;

  // Renamed 'outlets' to 'areas' to reflect the new logic
  areas: AreaSlide[] = [
    {
      name: 'Indiranagar',
      location: 'Bengaluru',
      image: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80',
      tagline: 'The heart of city nightlife.'
    },
    {
      name: 'Whitefield',
      location: 'Bengaluru',
      image: 'https://images.unsplash.com/photo-1552566626-52f8b828add9?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80',
      tagline: 'Spacious family dining.'
    },
    {
      name: 'Koramangala',
      location: 'Bengaluru',
      image: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80',
      tagline: 'Cozy vibes for students.'
    }
  ];

  constructor(private router: Router) {}

  scrollToOutlets() {
    this.outletSection.nativeElement.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  prevSlide() {
    this.currentIndex = (this.currentIndex === 0) ? this.areas.length - 1 : this.currentIndex - 1;
  }

  nextSlide() {
    this.currentIndex = (this.currentIndex === this.areas.length - 1) ? 0 : this.currentIndex + 1;
  }

  // UPDATED: Navigate to the new Restaurant List page
  // Example URL: /outlets/Indiranagar
  goToRestaurants(specificArea?: string) {
    const targetArea = specificArea || this.areas[this.currentIndex].name;
    this.router.navigate(['/outlets', targetArea]);
  }
}