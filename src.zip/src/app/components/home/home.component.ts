import { Component } from '@angular/core';
import { HomeBodyComponent } from '../home-body/home-body.component';
import { AboutUsComponent } from '../about-us/about-us.component'; // Ensure this exists
import { FooterComponent } from '../common/footer/footer.component';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [
    HomeBodyComponent,
    AboutUsComponent,
    FooterComponent,
  ],
  template: `
    <app-home-body></app-home-body>
    <div id="about-section">
      <app-about-us></app-about-us>
    </div>
    
    <app-footer></app-footer>
  `,
})
export class HomeComponent {}