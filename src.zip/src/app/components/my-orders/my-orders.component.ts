import { Component, OnInit, NgZone, ChangeDetectorRef } from '@angular/core'; // Import NgZone + CDR
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatListModule } from '@angular/material/list';
import { MatDividerModule } from '@angular/material/divider';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatIconModule } from '@angular/material/icon';
import { RouterModule } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

import { MenuService } from '../../services/menu.service';
import { AuthService } from '../../services/auth.service';
import { CustomerOrder } from '../../models/models';

@Component({
  selector: 'app-my-orders',
  standalone: true,
  imports: [
    CommonModule,
    MatCardModule,
    MatButtonModule,
    MatListModule,
    MatDividerModule,
    MatProgressSpinnerModule,
    MatIconModule,
    RouterModule
  ],
  templateUrl: './my-orders.component.html',
  styleUrls: ['./my-orders.component.css'],
})
export class MyOrdersComponent implements OnInit {
  
  orders: CustomerOrder[] = [];
  loading = true;
  errorMsg = '';
  updatingOrderId: number | null = null; 

  constructor(
    private menuService: MenuService,
    private authService: AuthService,
    private toastr: ToastrService,
    private http: HttpClient,
    private ngZone: NgZone,       // <--- Inject
    private cdr: ChangeDetectorRef // <--- Inject
  ) {}

  ngOnInit(): void {
    this.fetchOrders();
  }

  // --- HELPER: Fixes NG0100 Buffer Error ---
  private runInZone(callback: () => void) {
    this.ngZone.run(() => {
      setTimeout(() => {
        callback();
        this.cdr.detectChanges();
      }, 0);
    });
  }

  fetchOrders(): void {
    const username = this.authService.getUsername();
    if (!username) {
      this.errorMsg = 'User not logged in.';
      this.loading = false;
      return;
    }

    this.menuService.getOrdersByUsername(username).subscribe({
      next: (response) => {
        this.runInZone(() => {
          const data = response.data || response || [];
          this.orders = data.sort((a: CustomerOrder, b: CustomerOrder) => b.id - a.id);
          this.loading = false;
        });
      },
      error: (err) => {
        this.runInZone(() => {
          this.errorMsg = 'Error fetching orders.';
          console.error(err);
          this.loading = false;
        });
      },
    });
  }

  deleteOrder(orderId: number): void {
    if (!confirm('Are you sure you want to delete this order?')) return;

    this.menuService.deleteOrder(orderId).subscribe({
      next: () => {
        this.runInZone(() => {
          this.toastr.success('Order deleted successfully!');
          this.orders = this.orders.filter((o) => o.id !== orderId);
        });
      },
      error: (err) => {
        this.runInZone(() => {
          this.toastr.error('Failed to delete order');
        });
      },
    });
  }

  // --- UPDATE QUANTITY LOGIC ---
  updateQuantity(order: CustomerOrder, itemId: number, change: number) {
    // Set loading state immediately
    this.updatingOrderId = order.id; 

    const qtyMap = new Map<number, number>();
    order.orderItems.forEach((item: any) => {
      const id = item.id || item.menuItemId; 
      qtyMap.set(id, (qtyMap.get(id) || 0) + 1);
    });

    const currentQty = qtyMap.get(itemId) || 0;
    const newQty = currentQty + change;

    if (newQty <= 0) {
      qtyMap.delete(itemId);
    } else {
      qtyMap.set(itemId, newQty);
    }

    if (qtyMap.size === 0) {
      this.deleteOrder(order.id);
      this.updatingOrderId = null;
      return;
    }

    const orderItemsObj: any = {};
    qtyMap.forEach((val, key) => {
      orderItemsObj[key] = val;
    });

    const updatePayload = {
      customerName: order.customerName,
      customerPhoneNumber: order.customerPhoneNumber,
      customerAddress: order.customerAddress,
      outletId: order.outlet?.id, 
      orderItems: orderItemsObj
    };

    // FIX: Use the Correct New URL (/api/orders/update/...)
    const url = `http://localhost:8082/api/orders/update/${order.id}`;
    const token = this.authService.getToken();
    
    this.http.put(url, updatePayload, {
      headers: { 'Authorization': `Bearer ${token}` }
    }).subscribe({
      next: () => {
        this.runInZone(() => {
          this.toastr.success('Order updated!');
          this.fetchOrders(); // Refresh to reflect new price/items
          this.updatingOrderId = null;
        });
      },
      error: (err) => {
        this.runInZone(() => {
          console.error("Update Error:", err);
          this.toastr.error('Failed to update order');
          this.updatingOrderId = null;
        });
      }
    });
  }

  getGroupedItems(items: any[]): { id: number; name: string; qty: number; price: number }[] {
    const grouped = new Map<number, { id: number; name: string; qty: number; price: number }>();

    items.forEach((item) => {
      const name = item.foodName || item.menuItemName || 'Item';
      const price = item.foodPrice || item.price || 0;
      // Ensure we grab the ID safely
      const id = item.id || item.menuItemId;

      if (grouped.has(id)) {
        grouped.get(id)!.qty += 1;
      } else {
        grouped.set(id, {
          id: id,
          name: name,
          qty: 1,
          price: price,
        });
      }
    });

    return Array.from(grouped.values());
  }
}