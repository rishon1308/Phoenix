import { Component, OnInit, NgZone, ChangeDetectorRef } from '@angular/core'; // Import NgZone & CDR
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';

interface Outlet {
  id: number;
  outletName: string;
  area: string;
  outletDescription: string;
  imageUrl: string;
}

@Component({
  selector: 'app-restaurant-list',
  standalone: true,
  imports: [
    CommonModule, 
    HttpClientModule, 
    MatCardModule, 
    MatButtonModule, 
    MatIconModule,
    MatProgressSpinnerModule
  ],
  templateUrl: './restaurant-list.html',
  styleUrls: ['./restaurant-list.css']
})
export class RestaurantListComponent implements OnInit {
  
  areaName: string = '';
  restaurants: Outlet[] = [];
  isLoading: boolean = true;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private http: HttpClient,
    private ngZone: NgZone,       // <--- Inject NgZone
    private cdr: ChangeDetectorRef // <--- Inject CDR
  ) {}

  ngOnInit() {
    this.areaName = this.route.snapshot.paramMap.get('area') || '';
    if(this.areaName) {
      this.fetchRestaurants();
    }
  }

  fetchRestaurants() {
    this.isLoading = true;
    
    this.http.get<any>(`http://localhost:8082/outlets/area/${this.areaName}`)
      .subscribe({
        next: (response) => {
          // FORCE UPDATE INSIDE ANGULAR ZONE
          this.ngZone.run(() => {
            console.log('🔥 Restaurants Fetched:', response);
            
            // Handle ApiResponse wrapper or raw list
            if (response && response.data) {
              this.restaurants = response.data;
            } else if (Array.isArray(response)) {
              this.restaurants = response;
            }
            
            this.isLoading = false;
            this.cdr.detectChanges(); // Force screen update
          });
        },
        error: (err) => {
          this.ngZone.run(() => {
            console.error('❌ Failed to load restaurants', err);
            this.isLoading = false;
            this.cdr.detectChanges(); // Stop spinner even on error
          });
        }
      });
  }

  openMenu(outletId: number) {
    this.router.navigate(['/menu', outletId]);
  }
}