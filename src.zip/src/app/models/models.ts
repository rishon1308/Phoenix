// --- API WRAPPER ---
export interface ApiResponse<T> {
  message: string;
  data: T;
  status?: string; 
}

// --- USER ---
export interface User {
  user_id?: number;
  username: string;
  password?: string; 
  roles: 'ROLE_ADMIN' | 'ROLE_CUSTOMER';
}

// --- OUTLET (New) ---
export interface Outlet {
  id: number;
  outletName: string; // e.g., "KFC"
  area: string;       // e.g., "Indiranagar"
  outletDescription?: string;
  imageUrl?: string;
}

// --- MENU ITEM ---
export interface MenuItem {
  id: number;
  foodName: string;
  foodPrice: number;
  imageUrl?: string; 
  outlet?: Outlet;    // Link to specific outlet
  location?: string;  // Legacy support (optional)
}

// --- ORDER REQUEST (Sending to Backend) ---
export interface OrderRequest {
  customerName: string;
  customerPhoneNumber: string;
  customerAddress: string;
  outletId: number;   // NEW: Required to link order to restaurant
  // Java Map<Long, Integer> -> TS Object { 1: 2, 5: 1 }
  orderItems: { [key: number]: number }; 
}

// --- ORDER RESPONSE (Viewing History) ---
export interface CustomerOrder {
  id: number;
  customerName: string;
  customerPhoneNumber: string;
  customerAddress: string;
  totalPrice: number;
  orderDate?: string; // Optional date string
  
  // NEW: Order belongs to a specific outlet
  outlet: Outlet; 
  
  // Backend returns a flat list of MenuItems (e.g. [Burger, Burger, Coke])
  // We type it as any[] or MenuItem[] to avoid strict type clashes during mapping
  orderItems: any[]; 
}

// --- HELPER INTERFACE (For Grouping in UI) ---
export interface OrderItem {
  id: number;
  name: string;
  qty: number;
  price: number;
}